


import React, { useState, useCallback, useEffect } from 'react';
import { UserProfile, AppState, UserType, CareerRecommendation, User } from './types';
import UserTypeSelector from './components/UserTypeSelector';
import ProfileForm from './components/ProfileForm';
import ResultsDisplay from './components/ResultsDisplay';
import { getCareerRecommendations } from './services/geminiService';
import LoadingSpinner from './components/LoadingSpinner';
import ResumeBuilder from './components/ResumeBuilder';
import SignIn from './components/SignIn';
import SignUp from './components/SignUp';
import { signIn, signUp } from './services/authService';


const initialState: UserProfile = {
  name: '',
  email: '',
  phone: '',
  age: '',
  location: '',
  education10th: '',
  education10thSchool: '',
  education12th: '',
  education12thSchool: '',
  education12thStream: '',
  educationHistory: [],
  
  hardSkills: '',
  softSkills: '',
  toolsAndSoftware: '',
  certifications: '',
  languages: '',
  internships: '',
  projects: '',
  favoriteSubjects: '',
  subjectProficiency: {},
  quizAnswers: {},
  preferredIndustries: '',
  workPreferences: '',
  higherStudies: '',
  dreamJobRoles: '',
  resume: null,
};

const loadingMessages = [
  'Our AI is crafting your personalized career path. This might take a moment.',
  'Analyzing your academic background...',
  'Evaluating your unique skills and talents...',
  'Cross-referencing your interests with top industries...',
  'Identifying potential skill gaps and opportunities...',
  'Crafting personalized learning paths...',
  'Finalizing your top career matches...',
];

interface AppData {
    quizQuestions: any;
    educationFields: any[];
    formStructureByField: any;
}

function App() {
  const [appState, setAppState] = useState<AppState>(AppState.USER_TYPE_SELECTION);
  const [userType, setUserType] = useState<UserType | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile>(initialState);
  const [recommendations, setRecommendations] = useState<CareerRecommendation[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loadingMessageIndex, setLoadingMessageIndex] = useState(0);
  const [textFadeClass, setTextFadeClass] = useState('opacity-100');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [appData, setAppData] = useState<AppData | null>(null);
  const [dataError, setDataError] = useState<string | null>(null);

  useEffect(() => {
    const fetchAppData = async () => {
        try {
            const [quizRes, eduRes, formRes] = await Promise.all([
                fetch('./data/quizQuestions.json'),
                fetch('./data/educationFields.json'),
                fetch('./data/formStructureByField.json'),
            ]);

            if (!quizRes.ok || !eduRes.ok || !formRes.ok) {
                throw new Error('Failed to load critical application data.');
            }

            const quizQuestions = await quizRes.json();
            const educationFields = await eduRes.json();
            const formStructureByField = await formRes.json();

            setAppData({ quizQuestions, educationFields, formStructureByField });
        } catch (err: any) {
            setDataError(err.message || 'Could not load application resources. Please refresh the page.');
        }
    };
    fetchAppData();
  }, []);


  useEffect(() => {
    let intervalId: number | undefined;
    let timeoutId: number | undefined;
    if (appState === AppState.GENERATING) {
      setLoadingMessageIndex(0);
      setTextFadeClass('opacity-100');
      
      intervalId = window.setInterval(() => {
        setTextFadeClass('opacity-0'); // Fade out
        
        timeoutId = window.setTimeout(() => {
            setLoadingMessageIndex(prevIndex => (prevIndex + 1) % loadingMessages.length);
            setTextFadeClass('opacity-100'); // Fade in with new text
        }, 300); // Duration of fade

      }, 1800); // Cycle time
    }

    return () => {
      if (intervalId) clearInterval(intervalId);
      if (timeoutId) clearTimeout(timeoutId);
    };
}, [appState]);

  const handleUserTypeSelect = (type: UserType) => {
    setUserType(type);
    setAppState(AppState.SIGN_IN);
  };
  
  const handleSignUp = async (name: string, email: string, password: string) => {
    await signUp(name, email, password, userType!);
    alert('Account created successfully! Please sign in.');
    setAppState(AppState.SIGN_IN);
  };
  
  const handleSignIn = async (email: string, password: string) => {
    try {
        const user = await signIn(email, password, userType!);
        setCurrentUser(user);
        setUserProfile(prev => ({...prev, name: user.name, email: user.email }));
        setAppState(AppState.PROFILE_BUILDING);
    } catch (err: any) {
        // Re-throw other errors for the component to handle
        throw err;
    }
  };

  const handleNavigateToSignUp = () => setAppState(AppState.SIGN_UP);
  const handleNavigateToSignIn = () => setAppState(AppState.SIGN_IN);

  const handleProfileComplete = (profile: UserProfile) => {
    setUserProfile(profile);
    if (userType === UserType.IN_EDUCATION) {
      setAppState(AppState.RESUME_BUILDER);
    } else {
      handleFormSubmit(profile);
    }
  };

  const handleFormSubmit = useCallback(async (profile: UserProfile) => {
    if (!appData) {
        setError("Application data is not loaded. Cannot proceed.");
        return;
    }
    setAppState(AppState.GENERATING);
    setError(null);
    try {
      const result = await getCareerRecommendations(profile, userType!, appData.quizQuestions);
      if (result && result.recommendations) {
        setRecommendations(result.recommendations);
        setAppState(AppState.RESULTS);
      } else {
        throw new Error('Failed to get recommendations. The response was empty.');
      }
    } catch (err: any) {
      console.error("AI recommendation failed:", err);
      setError(err.message || "An error occurred while generating recommendations.");
      setAppState(AppState.PROFILE_BUILDING);
    }
  }, [userType, appData]);

  const handleResumeProceed = (updatedProfile: UserProfile) => {
    setUserProfile(updatedProfile);
    handleFormSubmit(updatedProfile);
  };

  const handleReset = () => {
    setUserProfile(initialState);
    setUserType(null);
    setRecommendations([]);
    setError(null);
    setCurrentUser(null);
    setAppState(AppState.USER_TYPE_SELECTION);
  };
  
  const handleBackToProfile = () => {
    setAppState(AppState.PROFILE_BUILDING);
  }

  const renderContent = () => {
    if (dataError) {
        return <div className="flex items-center justify-center h-screen text-center text-red-500 font-semibold p-4">{dataError}</div>
    }

    if (!appData) {
        return (
             <div className="flex flex-col items-center justify-center h-screen p-4">
                <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-md p-10 rounded-2xl shadow-2xl text-center flex flex-col items-center w-full max-w-lg">
                    <LoadingSpinner />
                    <h2 className="text-2xl font-bold mt-6 text-slate-800 dark:text-slate-100">Loading resources...</h2>
                </div>
            </div>
        )
    }

    switch (appState) {
      case AppState.USER_TYPE_SELECTION:
        return <UserTypeSelector onSelect={handleUserTypeSelect} />;
      case AppState.SIGN_IN:
        return <SignIn userType={userType!} onSignIn={handleSignIn} onNavigateToSignUp={handleNavigateToSignUp} />;
      case AppState.SIGN_UP:
        return <SignUp userType={userType!} onSignUp={handleSignUp} onNavigateToSignIn={handleNavigateToSignIn} />;
      case AppState.PROFILE_BUILDING:
        return (
          <ProfileForm
            userType={userType!}
            profile={userProfile}
            setProfile={setUserProfile}
            onComplete={handleProfileComplete}
            error={error}
            appData={appData}
          />
        );
      case AppState.RESUME_BUILDER:
        return (
            <ResumeBuilder
                profile={userProfile}
                onProceed={handleResumeProceed}
                onBack={handleBackToProfile}
            />
        );
      case AppState.GENERATING:
        return (
          <div className="flex flex-col items-center justify-center h-screen p-4">
            <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-md p-10 rounded-2xl shadow-2xl text-center flex flex-col items-center w-full max-w-lg">
                <LoadingSpinner />
                <h2 className="text-2xl font-bold mt-6 text-slate-800 dark:text-slate-100">Analyzing your profile...</h2>
                <div className="h-12 mt-2 flex items-center justify-center">
                    <p className={`text-slate-600 dark:text-slate-400 text-center transition-opacity duration-300 ease-in-out ${textFadeClass}`}>
                        {loadingMessages[loadingMessageIndex]}
                    </p>
                </div>
            </div>
          </div>
        )
      case AppState.RESULTS:
        return <ResultsDisplay recommendations={recommendations} onReset={handleReset} />;
      default:
        return <UserTypeSelector onSelect={handleUserTypeSelect} />;
    }
  };

  return <div className="min-h-screen font-sans">{renderContent()}</div>;
}

export default App;
