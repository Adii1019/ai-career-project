
import { GoogleGenAI, Type } from "@google/genai";
import { UserProfile, UserType, CareerRecommendation, EducationEntry } from '../types';
import { fallbackRecommendationsByField, FallbackCategory } from './fallbackData';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const resourceSchema = {
    type: Type.OBJECT,
    properties: {
        title: { type: Type.STRING, description: "The title of the resource." },
        url: { type: Type.STRING, description: "The direct, valid URL to the resource." }
    },
    required: ["title", "url"]
};

const schema = {
  type: Type.OBJECT,
  properties: {
    recommendations: {
      type: Type.ARRAY,
      description: "An array of 7 to 8 career recommendations.",
      items: {
        type: Type.OBJECT,
        properties: {
          careerTitle: { type: Type.STRING, description: "The title of the career path." },
          description: { type: Type.STRING, description: "A brief overview of what this career entails." },
          relevanceJustification: { type: Type.STRING, description: "Detailed explanation of why this career is a good fit for the user, referencing their profile." },
          skillGaps: {
            type: Type.ARRAY,
            description: "A list of skills the user is missing for this career.",
            items: { type: Type.STRING }
          },
          learningPath: {
            type: Type.ARRAY,
            description: "A step-by-step learning path to bridge the skill gaps.",
            items: {
              type: Type.OBJECT,
              properties: {
                step: { type: Type.STRING, description: "e.g., 'Online Course', 'Certification', 'Project'" },
                recommendation: { type: Type.STRING, description: "A specific recommendation, e.g., 'Complete the Google Data Analytics Professional Certificate on Coursera'." },
                details: { type: Type.STRING, description: "More details about the recommendation." }
              },
              required: ["step", "recommendation", "details"],
            }
          },
          youtubeTutorials: {
            type: Type.ARRAY,
            description: "A list of 2-3 relevant YouTube tutorial videos for this career.",
            items: resourceSchema
          },
          freeCourses: {
            type: Type.ARRAY,
            description: "A list of 2-3 top free online courses (e.g., from Coursera, edX).",
            items: resourceSchema
          },
          ebooksOrBlogs: {
            type: Type.ARRAY,
            description: "A list of 2-3 highly-rated eBooks or blog articles.",
            items: resourceSchema
          }
        },
        required: ["careerTitle", "description", "relevanceJustification", "skillGaps", "learningPath", "youtubeTutorials", "freeCourses", "ebooksOrBlogs"]
      }
    }
  },
  required: ["recommendations"]
};

const fileToBase64 = (file: File): Promise<string> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
        const base64String = (reader.result as string).split(',')[1];
        resolve(base64String);
    };
    reader.onerror = error => reject(error);
});


const buildPrompt = (profile: UserProfile, userType: UserType, allQuizQuestions: any): string => {
    const formatSubjectProficiency = (proficiency: { [key: string]: string }): string => {
        if (!proficiency || Object.keys(proficiency).length === 0) return 'Not specified';
        return Object.entries(proficiency)
            .map(([subject, level]) => `${subject}: ${level}`)
            .join(', ');
    };
    
    const formatQuizAnswers = (answers: { [key: string]: string }): string => {
        if (!answers || Object.keys(answers).length === 0) return 'Not specified';
        
        const questionsMap = Object.values(allQuizQuestions).flat().reduce((acc: any, q: any) => {
            acc[q.id] = q.question;
            return acc;
        }, {} as { [key: string]: string });

        return Object.entries(answers)
            .map(([questionId, answer]) => {
                const questionText = questionsMap[questionId] || questionId;
                return `\n    *   Q: ${questionText}\n    *   A: ${answer}`;
            })
            .join('');
    };

    const formatEducationHistory = (history: EducationEntry[]): string => {
        if (!history || history.length === 0) return '  *   Higher Education: Not specified';
        return history.map(entry => `
        *   Level: ${entry.level || 'Not specified'}
            *   Institution: ${entry.institution || 'Not specified'}
            *   Field: ${entry.field || 'Not specified'}
            *   Specialization: ${entry.specialization || 'Not specified'}
            *   Grade/CGPA: ${entry.grade || 'Not specified'}
            *   Duration: ${entry.startYear || '?'} - ${entry.endYear || '?'}`).join('');
    };

    return `
    **System Instruction:**
    You are an expert AI Career Counselor. Your goal is to provide personalized, actionable career guidance based on the user's profile. Analyze the provided data and generate 7 to 8 highly relevant career recommendations. For each recommendation, you must provide a detailed justification, identify skill gaps, and suggest a concrete learning path.
    **Crucially, for each career recommendation, you must also find and provide a list of relevant external learning resources: 2-3 YouTube tutorials, 2-3 top-rated free online courses, and 2-3 insightful eBooks or blog articles. Provide direct, valid URLs for all resources.**

    **User Profile:**
    *   **Status:** ${userType === UserType.IN_EDUCATION ? 'Currently in education' : 'Completed education / Professional'}
    *   **Personal:** Name: ${profile.name}, Email: ${profile.email}, Phone: ${profile.phone || 'Not provided'}, Age: ${profile.age}, Location: ${profile.location}
    *   **Academics:**
        *   10th Grade: School: ${profile.education10thSchool || 'Not specified'}, Percentage/CGPA: ${profile.education10th || 'Not specified'}
        *   12th Grade: School: ${profile.education12thSchool || 'Not specified'}, Percentage/CGPA: ${profile.education12th || 'Not specified'}, Stream: ${profile.education12thStream || 'Not specified'}
        *   **Higher Education:** ${formatEducationHistory(profile.educationHistory)}
    *   **Hard Skills:** ${profile.hardSkills || 'Not specified'}
    *   **Soft Skills:** ${profile.softSkills || 'Not specified'}
    *   **Tools & Software:** ${profile.toolsAndSoftware || 'Not specified'}
    *   **Internships / Work History:** ${profile.internships || 'Not specified'}
    *   **Projects:** ${profile.projects || 'Not specified'}
    *   **Certifications:** ${profile.certifications || 'Not specified'}
    *   **Languages:** ${profile.languages || 'Not specified'}
    *   **Subject Proficiency:** ${formatSubjectProficiency(profile.subjectProficiency)}
    *   **Knowledge Quiz Results:** ${formatQuizAnswers(profile.quizAnswers)}
    *   **Favorite Subjects & Interests:** ${profile.favoriteSubjects || 'Not specified'}
    *   **Preferred Industries:** ${profile.preferredIndustries || 'Not specified'}
    *   **Work Preferences:** ${profile.workPreferences || 'Not specified'}
    *   **Future Plans:** ${profile.higherStudies || 'Not specified'}
    *   **Dream Job Role(s):** ${profile.dreamJobRoles || 'Not specified'}
${userType === UserType.COMPLETED_EDUCATION && profile.resume ? `*   **Resume Analysis:** A resume file has been attached. Please perform a detailed analysis of this resume, extracting key experiences, accomplishments, and skills. The resume should be considered the primary source of truth for the candidate's professional background. Synthesize its contents with the profile data provided above.` : ''}

    **Your Task:**
    Based on all the information provided, return a JSON object that adheres to the provided schema. The recommendations should be ranked from most to least suitable. The justification should clearly link aspects of the user's profile (and resume, if provided) to the career. The skill gaps should be specific. The learning path should include a mix of online courses, certifications, and practical projects.
    `;
}

// Helper to determine the best fallback category based on the profile
const getFallbackCategory = (profile: UserProfile): FallbackCategory => {
    // 1. Check Highest Education Field first (Most specific)
    const latestEducation = profile.educationHistory.length > 0 ? profile.educationHistory[profile.educationHistory.length - 1] : null;
    
    if (latestEducation && latestEducation.field) {
        const field = latestEducation.field;
        
        // Exact matches to the keys in educationFields.json (as best as possible)
        if (field === "Engineering & Technology") return 'engineering';
        if (field === "Medical & Health Sciences") return 'medical';
        if (field === "Science (Pure & Applied)") return 'science_pure';
        if (field === "Commerce & Management") return 'commerce';
        if (field === "Arts, Humanities & Social Sciences") return 'arts';
        if (field === "Law") return 'law';
        if (field === "Agriculture & Veterinary Sciences") return 'agriculture';
        if (field === "Design, Architecture & Fine Arts") return 'design';
        if (field === "Computer Applications & IT") return 'computer_it';
        if (field === "Education / Teaching / Training") return 'education';
        
        // Loose matching if exact string fails
        const fLower = field.toLowerCase();
        if (fLower.includes('engineer')) return 'engineering';
        if (fLower.includes('medic') || fLower.includes('health') || fLower.includes('pharm') || fLower.includes('nurs')) return 'medical';
        if (fLower.includes('computer') || fLower.includes('it') || fLower.includes('software')) return 'computer_it';
        if (fLower.includes('design') || fLower.includes('art') || fLower.includes('arch')) return 'design';
        if (fLower.includes('law') || fLower.includes('legal')) return 'law';
        if (fLower.includes('agri')) return 'agriculture';
        if (fLower.includes('teach') || fLower.includes('education')) return 'education';
        if (fLower.includes('commerce') || fLower.includes('business') || fLower.includes('manage')) return 'commerce';
        if (fLower.includes('science')) return 'science_pure';
        if (fLower.includes('art') || fLower.includes('human')) return 'arts';
    }

    // 2. Check 12th Stream if no higher education
    if (profile.education12thStream) {
        const stream = profile.education12thStream.toLowerCase();
        if (stream.includes('pcm') || stream.includes('technology') || stream.includes('engineering')) return 'engineering';
        if (stream.includes('pcb') || stream.includes('medic')) return 'medical';
        if (stream.includes('commerce')) return 'commerce';
        if (stream.includes('arts') || stream.includes('humanities') || stream.includes('media')) return 'arts';
        if (stream.includes('computer') || stream.includes('it')) return 'computer_it';
        if (stream.includes('agriculture')) return 'agriculture';
        if (stream.includes('fashion') || stream.includes('design')) return 'design';
        if (stream.includes('vocational')) return 'default'; // Or map specific vocations
    }

    // Fallback to default
    return 'default';
};

// Helper function to calculate a simple relevance score based on keyword matching
const calculateRelevance = (recommendation: CareerRecommendation, keywords: string): number => {
    let score = 0;
    const recString = `${recommendation.careerTitle} ${recommendation.description} ${recommendation.relevanceJustification}`.toLowerCase();
    
    // Check for exact word matches from the profile keywords
    const keywordArray = keywords.split(/\s+/).filter(k => k.length > 3); // Filter out short words
    
    keywordArray.forEach(k => {
        if (recString.includes(k)) {
            score += 1;
        }
    });
    
    return score;
};


export const getCareerRecommendations = async (profile: UserProfile, userType: UserType, allQuizQuestions: any): Promise<{ recommendations: CareerRecommendation[] }> => {
  const prompt = buildPrompt(profile, userType, allQuizQuestions);

  let apiContents: any;

  if (userType === UserType.COMPLETED_EDUCATION && profile.resume) {
      try {
          const base64Data = await fileToBase64(profile.resume);
          const resumePart = {
              inlineData: {
                  mimeType: profile.resume.type,
                  data: base64Data
              }
          };
          const textPart = { text: prompt };
          apiContents = { parts: [textPart, resumePart] };
      } catch (error) {
          console.error("Error converting file to base64:", error);
          apiContents = prompt; // Fallback to text-only if file conversion fails
      }
  } else {
      apiContents = prompt;
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: apiContents,
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
      },
    });

    const jsonText = response.text.trim();
    return JSON.parse(jsonText);

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    // Use fallback data
    console.warn("Falling back to offline recommendations.");
    
    const category = getFallbackCategory(profile);
    
    // Clone the recommendations so we can sort them without mutating the source
    let recommendations = [...fallbackRecommendationsByField[category]];
    
    // Construct a keyword string from relevant profile fields
    const profileKeywords = [
        profile.educationHistory.map(e => `${e.field || ''} ${e.specialization || ''}`).join(' '),
        profile.education12thStream || '',
        profile.dreamJobRoles || '',
        profile.favoriteSubjects || '',
        profile.preferredIndustries || ''
    ].join(' ').toLowerCase();

    // Sort the static list based on keyword relevance to the specific profile
    recommendations.sort((a, b) => {
        const scoreA = calculateRelevance(a, profileKeywords);
        const scoreB = calculateRelevance(b, profileKeywords);
        return scoreB - scoreA; // Descending order
    });

    // Simulate a slight delay to make it feel like processing
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    return { recommendations };
  }
};
