
import { User, UserType } from '../types';

// In a real app, this would be a secure, server-side database.
// localStorage is used here for demonstration purposes only.

const USERS_STORAGE_KEY = 'career_recommendation_users';

// A simple in-memory representation of the stored user data
interface StoredUser extends User {
    // In a real app, you would never store the password in plain text.
    // This would be a securely hashed password.
    password: string;
}

const getUsers = (): StoredUser[] => {
    try {
        const usersJson = localStorage.getItem(USERS_STORAGE_KEY);
        return usersJson ? JSON.parse(usersJson) : [];
    } catch (error) {
        console.error("Could not parse users from localStorage", error);
        return [];
    }
};

const saveUsers = (users: StoredUser[]): void => {
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
};

export const signUp = (name: string, email: string, password: string, userType: UserType): Promise<User> => {
    return new Promise((resolve, reject) => {
        // Simulate network delay
        setTimeout(() => {
            const users = getUsers();
            
            // Note: The check for existing users has been removed as requested.
            // This allows multiple accounts with the same email in this demo environment.

            const newUser: StoredUser = {
                id: new Date().toISOString() + Math.random(),
                name,
                email,
                password, // In a real-world scenario, hash this password before saving.
                userType,
                verified: true, // Auto-verify accounts.
            };

            users.push(newUser);
            saveUsers(users);
            
            const { password: _, ...userToReturn } = newUser;
            resolve(userToReturn);

        }, 500);
    });
};


export const signIn = (email: string, password: string, userType: UserType):Promise<User> => {
     return new Promise((resolve, reject) => {
        // Simulate network delay
        setTimeout(() => {
            const users = getUsers();
            const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());

            if (!user || user.password !== password || user.userType !== userType) {
                 return reject(new Error('Invalid email, password, or account type.'));
            }

            const { password: _, ...userToReturn } = user;
            resolve(userToReturn);
        }, 500);
    });
};
