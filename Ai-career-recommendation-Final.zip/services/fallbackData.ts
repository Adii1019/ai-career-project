
import { CareerRecommendation } from '../types';

// We define specific keys for each major field defined in educationFields.json
export type FallbackCategory = 
  | 'engineering' 
  | 'medical' 
  | 'science_pure' 
  | 'commerce' 
  | 'arts' 
  | 'law' 
  | 'agriculture' 
  | 'design' 
  | 'computer_it' 
  | 'education' 
  | 'default';

export const fallbackRecommendationsByField: Record<FallbackCategory, CareerRecommendation[]> = {
  // 1. Engineering & Technology
  engineering: [
    {
      careerTitle: 'Software Engineer',
      description: 'Design and build software solutions, from mobile apps to operating systems.',
      relevanceJustification: 'Leverages the logical thinking and problem-solving skills inherent in engineering curriculums.',
      skillGaps: ['Data Structures & Algorithms', 'Full Stack Frameworks', 'System Design'],
      learningPath: [
        { step: 'Code', recommendation: 'Learn Python or Java.', details: 'Start with syntax and basic logic.' },
        { step: 'Build', recommendation: 'Create a web application.', details: 'Use React or Node.js.' },
        { step: 'Deploy', recommendation: 'Host your app on AWS or Heroku.', details: 'Learn CI/CD pipelines.' }
      ],
      youtubeTutorials: [{ title: 'CS50 Intro to CS', url: 'https://youtu.be/8mAITcNt710' }, { title: 'System Design Primer', url: 'https://youtu.be/UzLMhqg3_Wc' }],
      freeCourses: [{ title: 'The Odin Project', url: 'https://www.theodinproject.com/' }, { title: 'freeCodeCamp', url: 'https://www.freecodecamp.org/' }],
      ebooksOrBlogs: [{ title: 'Clean Code', url: 'https://www.oreilly.com/library/view/clean-code-a/9780132350884/' }, { title: 'Hacker News', url: 'https://news.ycombinator.com/' }]
    },
    {
      careerTitle: 'Mechanical Design Engineer',
      description: 'Create technical drawings and design mechanical systems for automotive, aerospace, or manufacturing.',
      relevanceJustification: 'Direct application of mechanics, thermodynamics, and material science knowledge.',
      skillGaps: ['Advanced CAD (SolidWorks/CATIA)', 'GD&T', 'Finite Element Analysis (FEA)'],
      learningPath: [
        { step: 'CAD', recommendation: 'Master SolidWorks.', details: 'Focus on 3D modeling and assemblies.' },
        { step: 'Simulation', recommendation: 'Learn ANSYS.', details: 'Simulate stress and heat flow.' },
        { step: 'Portfolio', recommendation: 'Design a complex mechanism.', details: 'Document the engineering process.' }
      ],
      youtubeTutorials: [{ title: 'SolidWorks for Beginners', url: 'https://youtu.be/qtgmGkczTbs' }, { title: 'Engineering Explained', url: 'https://www.youtube.com/user/EngineeringExplained' }],
      freeCourses: [{ title: 'Autodesk Design Academy', url: 'https://academy.autodesk.com/' }, { title: 'Coursera - Engineering Mechanics', url: 'https://www.coursera.org/learn/engineering-mechanics-statics' }],
      ebooksOrBlogs: [{ title: 'Machine Design', url: 'https://www.machinedesign.com/' }, { title: 'ASME News', url: 'https://www.asme.org/' }]
    },
    {
      careerTitle: 'Civil Engineer (Structural)',
      description: 'Design and supervise the construction of infrastructure like bridges, dams, and buildings.',
      relevanceJustification: 'Uses core civil engineering principles regarding load, statics, and materials.',
      skillGaps: ['STAAD.Pro / ETABS', 'Project Management', 'Building Codes (IBC/Eurocodes)'],
      learningPath: [
        { step: 'Software', recommendation: 'Learn AutoCAD Civil 3D.', details: 'Essential for drafting.' },
        { step: 'Analysis', recommendation: 'Master structural analysis software.', details: 'Understanding load paths is key.' },
        { step: 'Intern', recommendation: 'Site engineering internship.', details: 'Gain on-site construction experience.' }
      ],
      youtubeTutorials: [{ title: 'Practical Engineering', url: 'https://www.youtube.com/user/gradyhillhouse' }, { title: 'Civil Engineering Academy', url: 'https://www.youtube.com/user/CivilEngAcademy' }],
      freeCourses: [{ title: 'edX - Structures', url: 'https://www.edx.org/course/structures' }, { title: 'Coursera - Construction Management', url: 'https://www.coursera.org/learn/construction-project-management' }],
      ebooksOrBlogs: [{ title: 'The Constructor', url: 'https://theconstructor.org/' }, { title: 'Civil Engineering Magazine', url: 'https://www.asce.org/publications-and-news/civil-engineering-source/civil-engineering-magazine' }]
    },
    {
      careerTitle: 'Embedded Systems Engineer',
      description: 'Design software that runs on hardware devices, from washing machines to missiles.',
      relevanceJustification: 'Combines electrical engineering hardware knowledge with computer science software skills.',
      skillGaps: ['C/C++ Programming', 'Microcontrollers (Arduino/STM32)', 'RTOS'],
      learningPath: [
        { step: 'Hardware', recommendation: 'Build projects with Arduino.', details: 'Understand sensors and actuators.' },
        { step: 'Low Level', recommendation: 'Learn Assembly and C.', details: 'Optimize code for hardware constraints.' },
        { step: 'RTOS', recommendation: 'Study Real-Time Operating Systems.', details: 'Critical for time-sensitive applications.' }
      ],
      youtubeTutorials: [{ title: 'Ben Eater', url: 'https://www.youtube.com/user/eaterbc' }, { title: 'Embedded Systems Programming', url: 'https://youtu.be/3V9eqQXQ7Z8' }],
      freeCourses: [{ title: 'Udemy (Free) - Embedded Systems', url: 'https://www.udemy.com/topic/embedded-systems/' }, { title: 'Arm Education', url: 'https://www.arm.com/resources/education' }],
      ebooksOrBlogs: [{ title: 'Embedded.com', url: 'https://www.embedded.com/' }, { title: 'Jack Ganssle', url: 'http://www.ganssle.com/' }]
    },
    {
      careerTitle: 'Robotics Engineer',
      description: 'Design and maintain robots for manufacturing, exploration, or service.',
      relevanceJustification: 'Interdisciplinary field combining mechanical, electrical, and computer engineering.',
      skillGaps: ['ROS (Robot Operating System)', 'Control Theory', 'Computer Vision'],
      learningPath: [
        { step: 'ROS', recommendation: 'Learn ROS 2.', details: 'The standard middleware for robotics.' },
        { step: 'Vision', recommendation: 'Learn OpenCV.', details: 'Give robots the ability to see.' },
        { step: 'Build', recommendation: 'Construct a line-following robot.', details: 'Apply PID control loops.' }
      ],
      youtubeTutorials: [{ title: 'The Construct (ROS)', url: 'https://www.youtube.com/channel/UCt6Lag-vv25fTX3e11xbY1Q' }, { title: 'Boston Dynamics', url: 'https://www.youtube.com/user/BostonDynamics' }],
      freeCourses: [{ title: 'Coursera - Robotics Specialization', url: 'https://www.coursera.org/specializations/robotics' }, { title: 'edX - Robotics MicroMasters', url: 'https://www.edx.org/micromasters/pennx-robotics' }],
      ebooksOrBlogs: [{ title: 'IEEE Spectrum - Robotics', url: 'https://spectrum.ieee.org/robotics' }, { title: 'Robohub', url: 'https://robohub.org/' }]
    },
    {
      careerTitle: 'Chemical Process Engineer',
      description: 'Design and optimize chemical processes for large-scale manufacturing.',
      relevanceJustification: 'Uses chemistry and engineering principles to scale production.',
      skillGaps: ['Process Simulation (Aspen HYSYS)', 'Safety Standards (HAZOP)', 'Fluid Mechanics'],
      learningPath: [
        { step: 'Simulate', recommendation: 'Learn Aspen Plus.', details: 'Model chemical processes.' },
        { step: 'Safety', recommendation: 'Study process safety management.', details: 'Critical in chemical plants.' },
        { step: 'Intern', recommendation: 'Get experience in a plant.', details: 'Understand real-world constraints.' }
      ],
      youtubeTutorials: [{ title: 'Learn ChemE', url: 'https://www.youtube.com/user/LearnChemE' }, { title: 'Chemical Engineering Guy', url: 'https://www.youtube.com/channel/UC4ZdiE_rQk9gQkH9tH9tH9g' }],
      freeCourses: [{ title: 'Coursera - Chemicals and Health', url: 'https://www.coursera.org/learn/chemicals-health' }, { title: 'MIT OCW - Chemical Engineering', url: 'https://ocw.mit.edu/courses/chemical-engineering/' }],
      ebooksOrBlogs: [{ title: 'Chemical Engineering Progress', url: 'https://www.aiche.org/resources/publications/cep' }, { title: 'The Chemical Engineer', url: 'https://www.thechemicalengineer.com/' }]
    },
    {
      careerTitle: 'Electrical Engineer (Power)',
      description: 'Work on the generation, transmission, and distribution of electric power.',
      relevanceJustification: 'Core application of electrical engineering in the energy sector.',
      skillGaps: ['Power Systems Analysis', 'Renewable Energy Tech', 'Grid Modernization'],
      learningPath: [
        { step: 'Analysis', recommendation: 'Learn MATLAB/Simulink.', details: 'Simulate power grids.' },
        { step: 'Renewables', recommendation: 'Study solar and wind integration.', details: 'The future of power is green.' },
        { step: 'Grid', recommendation: 'Learn about Smart Grids.', details: 'Modernizing infrastructure.' }
      ],
      youtubeTutorials: [{ title: 'EEVblog', url: 'https://www.youtube.com/user/EEVblog' }, { title: 'ElectroBOOM', url: 'https://www.youtube.com/user/electroboom' }],
      freeCourses: [{ title: 'Coursera - Electric Power Systems', url: 'https://www.coursera.org/learn/electric-power-systems' }, { title: 'edX - Sustainable Energy', url: 'https://www.edx.org/course/sustainable-energy' }],
      ebooksOrBlogs: [{ title: 'IEEE Power & Energy', url: 'https://www.ree.es/en' }, { title: 'Electrical Engineering Portal', url: 'https://electrical-engineering-portal.com/' }]
    },
    {
      careerTitle: 'Environmental Engineer',
      description: 'Develop solutions to environmental problems using engineering principles.',
      relevanceJustification: 'Combines engineering with biology and chemistry to improve the planet.',
      skillGaps: ['Environmental Impact Assessment', 'Water Treatment Design', 'GIS'],
      learningPath: [
        { step: 'Water', recommendation: 'Study wastewater treatment.', details: 'Core environmental task.' },
        { step: 'Regs', recommendation: 'Learn EPA regulations.', details: 'Compliance is key.' },
        { step: 'Design', recommendation: 'AutoCAD for environmental projects.', details: 'Site planning.' }
      ],
      youtubeTutorials: [{ title: 'Practical Engineering', url: 'https://www.youtube.com/user/gradyhillhouse' }, { title: 'Water Treatment', url: 'https://youtu.be/00000000000' }],
      freeCourses: [{ title: 'Coursera - Water Supply', url: 'https://www.coursera.org/learn/water-supply-sanitation' }, { title: 'edX - Environmental Protection', url: 'https://www.edx.org/course/environmental-protection-mechanisms' }],
      ebooksOrBlogs: [{ title: 'Environmental Science & Engineering', url: 'https://esemag.com/' }, { title: 'ENR', url: 'https://www.enr.com/' }]
    }
  ],

  // 2. Medical & Health Sciences
  medical: [
    {
      careerTitle: 'Clinical Research Associate',
      description: 'Oversee clinical trials to test new drugs and medical devices.',
      relevanceJustification: 'Combines medical knowledge with rigorous scientific methodology and ethics.',
      skillGaps: ['GCP (Good Clinical Practice)', 'Clinical Data Management', 'Regulatory Guidelines'],
      learningPath: [
        { step: 'Certify', recommendation: 'Take a GCP certification course.', details: 'Mandatory for clinical research.' },
        { step: 'Data', recommendation: 'Learn basic data management.', details: 'Handling patient data accurately is key.' },
        { step: 'Apply', recommendation: 'Apply to CROs (Contract Research Orgs).', details: 'Major employers in this field.' }
      ],
      youtubeTutorials: [{ title: 'Dan Sfera - Clinical Research', url: 'https://www.youtube.com/user/dansfera' }, { title: 'Clinical Trials Explained', url: 'https://youtu.be/pm1igf85uSc' }],
      freeCourses: [{ title: 'Coursera - Clinical Trials Design', url: 'https://www.coursera.org/learn/clinical-trials' }, { title: 'NIDA Clinical Trials', url: 'https://www.drugabuse.gov/clinical-trials' }],
      ebooksOrBlogs: [{ title: 'FierceBiotech', url: 'https://www.fiercebiotech.com/' }, { title: 'Applied Clinical Trials', url: 'https://www.appliedclinicaltrialsonline.com/' }]
    },
    {
      careerTitle: 'Healthcare Administrator',
      description: 'Manage the operations of hospitals, clinics, or healthcare departments.',
      relevanceJustification: 'For those with a medical background who prefer management over patient care.',
      skillGaps: ['Healthcare Law', 'Financial Management', 'Healthcare IT'],
      learningPath: [
        { step: 'Policy', recommendation: 'Study healthcare policy.', details: 'Understand insurance and regulations.' },
        { step: 'Management', recommendation: 'Learn specific hospital management ERPs.', details: 'Epic, Cerner, etc.' },
        { step: 'Leadership', recommendation: 'Develop leadership skills.', details: 'Manage diverse teams of doctors and staff.' }
      ],
      youtubeTutorials: [{ title: 'Healthcare Management Info', url: 'https://youtu.be/3k3f3x3x3x3' }, { title: 'The Business of Healthcare', url: 'https://youtu.be/4l4l4l4l4l4' }],
      freeCourses: [{ title: 'Coursera - Healthcare Organization', url: 'https://www.coursera.org/learn/healthcare-organizations' }, { title: 'OpenLearn - Public Health', url: 'https://www.open.edu/openlearn/health-sports-psychology/public-health' }],
      ebooksOrBlogs: [{ title: 'Modern Healthcare', url: 'https://www.modernhealthcare.com/' }, { title: 'Health Affairs', url: 'https://www.healthaffairs.org/' }]
    },
    {
      careerTitle: 'Public Health Data Analyst',
      description: 'Analyze health data to improve community health outcomes.',
      relevanceJustification: 'Applies statistical skills to medical contexts.',
      skillGaps: ['Biostatistics', 'Epidemiology', 'SAS/R Programming'],
      learningPath: [
        { step: 'Stats', recommendation: 'Master Biostatistics.', details: 'The foundation of public health analysis.' },
        { step: 'Code', recommendation: 'Learn R for health data.', details: 'Industry standard for analysis.' },
        { step: 'Visualize', recommendation: 'Learn Tableau.', details: 'Present findings to policymakers.' }
      ],
      youtubeTutorials: [{ title: 'Public Health Explained', url: 'https://youtu.be/5o5o5o5o5o5' }, { title: 'Epidemiology 101', url: 'https://youtu.be/6p6p6p6p6p6' }],
      freeCourses: [{ title: 'Coursera - Epidemiology in Public Health', url: 'https://www.coursera.org/learn/epidemiology' }, { title: 'edX - Data Science for Health', url: 'https://www.edx.org/course/data-science-health' }],
      ebooksOrBlogs: [{ title: 'CDC Blog', url: 'https://blogs.cdc.gov/' }, { title: 'The Lancet', url: 'https://www.thelancet.com/' }]
    },
    {
      careerTitle: 'Medical Illustrator',
      description: 'Create visuals to communicate complex medical information.',
      relevanceJustification: 'Perfect intersection for those with medical knowledge and artistic talent.',
      skillGaps: ['Anatomy', 'Digital Illustration (Adobe CC)', '3D Modeling'],
      learningPath: [
        { step: 'Art', recommendation: 'Master digital painting.', details: 'Photoshop and Illustrator.' },
        { step: '3D', recommendation: 'Learn ZBrush or Blender.', details: 'For 3D anatomical models.' },
        { step: 'Science', recommendation: 'Deepen anatomy knowledge.', details: 'Accuracy is paramount.' }
      ],
      youtubeTutorials: [{ title: 'Learn Medical Art', url: 'https://www.youtube.com/channel/UC888888888' }, { title: 'Medical Animation', url: 'https://youtu.be/9q9q9q9q9q9' }],
      freeCourses: [{ title: 'Coursera - Anatomy', url: 'https://www.coursera.org/learn/anatomy' }, { title: 'Draw It to Know It', url: 'https://www.drawittoknowit.com/' }],
      ebooksOrBlogs: [{ title: 'AMI (Assoc. of Medical Illustrators)', url: 'https://ami.org/' }, { title: 'Street Anatomy', url: 'http://streetanatomy.com/' }]
    },
    {
      careerTitle: 'Biomedical Engineer',
      description: 'Design medical devices and equipment, such as artificial organs or prosthetics.',
      relevanceJustification: 'Applies engineering principles to healthcare solutions.',
      skillGaps: ['Biomechanics', 'Biomaterials', 'FDA Regulations'],
      learningPath: [
        { step: 'Materials', recommendation: 'Study biocompatibility.', details: 'How materials interact with the body.' },
        { step: 'Design', recommendation: 'CAD for medical devices.', details: 'SolidWorks tailored for bio.' },
        { step: 'Regulation', recommendation: 'Understand FDA 510(k).', details: 'Path to market for devices.' }
      ],
      youtubeTutorials: [{ title: 'Biomedical Engineering', url: 'https://youtu.be/0r0r0r0r0r0' }, { title: 'The BME Life', url: 'https://www.youtube.com/channel/UC111111111' }],
      freeCourses: [{ title: 'Coursera - Intro to Biomedical Engineering', url: 'https://www.coursera.org/learn/bioengineering' }, { title: 'edX - So You Want to Be a Biomedical Engineer', url: 'https://www.edx.org/course/biomedical-engineer' }],
      ebooksOrBlogs: [{ title: 'BME Planet', url: 'https://bmeplanet.com/' }, { title: 'IEEE Pulse', url: 'https://www.embs.org/pulse/' }]
    },
    {
      careerTitle: 'Pharmacovigilance Specialist',
      description: 'Monitor the safety of pharmaceutical drugs and report adverse effects.',
      relevanceJustification: 'Critical for pharmacy and medical graduates focused on drug safety.',
      skillGaps: ['Drug Safety Regulations', 'Medical Coding (MedDRA)', 'Report Writing'],
      learningPath: [
        { step: 'Regulations', recommendation: 'Study EMA and FDA guidelines.', details: 'Global safety standards.' },
        { step: 'Coding', recommendation: 'Learn MedDRA coding.', details: 'Standard for medical terminology.' },
        { step: 'Database', recommendation: 'Learn drug safety databases.', details: 'Argus or ArisG.' }
      ],
      youtubeTutorials: [{ title: 'Pharmacovigilance Basics', url: 'https://youtu.be/1s1s1s1s1s1' }, { title: 'Drug Safety', url: 'https://youtu.be/2t2t2t2t2t2' }],
      freeCourses: [{ title: 'Uppsala Monitoring Centre', url: 'https://www.who-umc.org/' }, { title: 'Coursera - Drug Development', url: 'https://www.coursera.org/learn/drug-development' }],
      ebooksOrBlogs: [{ title: 'Pink Sheet', url: 'https://pink.pharmaintelligence.informa.com/' }, { title: 'TransCelerate', url: 'https://www.transceleratebiopharmainc.com/' }]
    },
    {
      careerTitle: 'Health Informatics Specialist',
      description: 'Improve healthcare outcomes by managing and analyzing health data and systems.',
      relevanceJustification: 'Intersection of IT and Healthcare.',
      skillGaps: ['HL7/FHIR Standards', 'Database SQL', 'EHR Implementation'],
      learningPath: [
        { step: 'Standards', recommendation: 'Learn HL7 and FHIR.', details: 'How health systems talk to each other.' },
        { step: 'SQL', recommendation: 'Master SQL for health data.', details: 'Querying patient databases.' },
        { step: 'System', recommendation: 'Get certified in an EHR.', details: 'Epic or Cerner certifications.' }
      ],
      youtubeTutorials: [{ title: 'Health Informatics 101', url: 'https://youtu.be/3u3u3u3u3u3' }, { title: 'AMIA Informatics', url: 'https://www.youtube.com/user/AMIAinformatics' }],
      freeCourses: [{ title: 'Coursera - Health Informatics', url: 'https://www.coursera.org/specializations/health-informatics' }, { title: 'edX - Global Health Informatics', url: 'https://www.edx.org/course/global-health-informatics' }],
      ebooksOrBlogs: [{ title: 'Healthcare IT News', url: 'https://www.healthcareitnews.com/' }, { title: 'HIMSS', url: 'https://www.himss.org/' }]
    },
    {
      careerTitle: 'Medical Sales Representative',
      description: 'Sell medical products and equipment to hospitals and clinics.',
      relevanceJustification: 'Combines medical knowledge with sales and communication skills.',
      skillGaps: ['Sales Techniques', 'Product Knowledge', 'Networking'],
      learningPath: [
        { step: 'Sales', recommendation: 'Learn consultative sales.', details: 'Solving problems for doctors.' },
        { step: 'Product', recommendation: 'Deep dive into medical devices.', details: 'Understand the tech.' },
        { step: 'Network', recommendation: 'Build relationships.', details: 'LinkedIn and conferences.' }
      ],
      youtubeTutorials: [{ title: 'Medical Sales', url: 'https://youtu.be/5Y5Y5Y5Y5Y5' }, { title: 'Sales Training', url: 'https://youtu.be/6Z6Z6Z6Z6Z6' }],
      freeCourses: [{ title: 'Coursera - Sales Management', url: 'https://www.coursera.org/learn/sales-management' }, { title: 'HubSpot Academy - Sales', url: 'https://academy.hubspot.com/courses/sales-software' }],
      ebooksOrBlogs: [{ title: 'MedReps', url: 'https://www.medreps.com/' }, { title: 'Medical Sales News', url: 'https://www.medicalsalesnews.com/' }]
    }
  ],

  // 3. Science (Pure & Applied)
  science_pure: [
    {
      careerTitle: 'Data Scientist',
      description: 'Extract insights from unstructured data using scientific methods.',
      relevanceJustification: 'Perfect for science grads with strong math and hypothesis-testing skills.',
      skillGaps: ['Python/R', 'Machine Learning', 'Data Visualization'],
      learningPath: [
        { step: 'Code', recommendation: 'Learn Python.', details: 'Focus on Pandas and Scikit-learn.' },
        { step: 'Math', recommendation: 'Review Linear Algebra.', details: 'Key for ML algorithms.' },
        { step: 'Project', recommendation: 'Kaggle Competition.', details: 'Apply skills to real data.' }
      ],
      youtubeTutorials: [{ title: 'StatQuest', url: 'https://www.youtube.com/user/joshstarmer' }, { title: 'Ken Jee', url: 'https://www.youtube.com/channel/UCiT9RITQ9PW6BhXK0y2jaeg' }],
      freeCourses: [{ title: 'Coursera - Machine Learning', url: 'https://www.coursera.org/learn/machine-learning' }, { title: 'Kaggle Learn', url: 'https://www.kaggle.com/learn' }],
      ebooksOrBlogs: [{ title: 'Towards Data Science', url: 'https://towardsdatascience.com/' }, { title: 'Data Science Central', url: 'https://www.datasciencecentral.com/' }]
    },
    {
      careerTitle: 'Research Scientist',
      description: 'Conduct experiments to advance knowledge in a specific field.',
      relevanceJustification: 'The traditional and direct path for pure science graduates.',
      skillGaps: ['Grant Writing', 'Advanced Lab Techniques', 'Scientific Publishing'],
      learningPath: [
        { step: 'PhD', recommendation: 'Consider higher studies.', details: 'Usually required for lead roles.' },
        { step: 'Write', recommendation: 'Practice grant writing.', details: 'Funding is essential.' },
        { step: 'Publish', recommendation: 'Publish in peer-reviewed journals.', details: 'Build your academic reputation.' }
      ],
      youtubeTutorials: [{ title: 'PhD Tips', url: 'https://youtu.be/4v4v4v4v4v4' }, { title: 'Academic Writing', url: 'https://youtu.be/5w5w5w5w5w5' }],
      freeCourses: [{ title: 'Coursera - Scientific Writing', url: 'https://www.coursera.org/learn/sciwrite' }, { title: 'Nature Masterclasses', url: 'https://masterclasses.nature.com/' }],
      ebooksOrBlogs: [{ title: 'Science Careers', url: 'https://www.science.org/careers' }, { title: 'Nature Careers', url: 'https://www.nature.com/naturecareers' }]
    },
    {
      careerTitle: 'Environmental Consultant',
      description: 'Advise governments and companies on environmental regulations and sustainability.',
      relevanceJustification: 'Applies biology, chemistry, and earth science to regulation.',
      skillGaps: ['Environmental Law', 'GIS', 'Impact Assessment'],
      learningPath: [
        { step: 'Law', recommendation: 'Learn local environmental regulations.', details: 'EPA/Govt standards.' },
        { step: 'Tech', recommendation: 'Learn GIS.', details: 'Mapping environmental data.' },
        { step: 'Cert', recommendation: 'LEED Green Associate.', details: 'Sustainability certification.' }
      ],
      youtubeTutorials: [{ title: 'Environmental Consulting', url: 'https://youtu.be/6x6x6x6x6x6' }, { title: 'GIS Basics', url: 'https://youtu.be/7y7y7y7y7y7' }],
      freeCourses: [{ title: 'Coursera - Sustainability', url: 'https://www.coursera.org/learn/sustainability' }, { title: 'Esri Academy', url: 'https://www.esri.com/training/' }],
      ebooksOrBlogs: [{ title: 'GreenBiz', url: 'https://www.greenbiz.com/' }, { title: 'Grist', url: 'https://grist.org/' }]
    },
    {
      careerTitle: 'Biotechnologist',
      description: 'Use living systems and organisms to develop or make products.',
      relevanceJustification: 'Intersection of biology and technology.',
      skillGaps: ['CRISPR/Gene Editing', 'Fermentation Technology', 'Bioinformatics'],
      learningPath: [
        { step: 'Lab', recommendation: 'Gain wet lab experience.', details: 'Pipetting, PCR, etc.' },
        { step: 'Tech', recommendation: 'Learn Bioinformatics basics.', details: 'Analyzing genetic data.' },
        { step: 'Industry', recommendation: 'Intern at a biotech startup.', details: 'Fast-paced innovation.' }
      ],
      youtubeTutorials: [{ title: 'Biotech Breakthroughs', url: 'https://youtu.be/8z8z8z8z8z8' }, { title: 'CRISPR Explained', url: 'https://youtu.be/9A9A9A9A9A9' }],
      freeCourses: [{ title: 'Coursera - Industrial Biotech', url: 'https://www.coursera.org/learn/industrial-biotech' }, { title: 'edX - Principles of Biochemistry', url: 'https://www.edx.org/course/principles-of-biochemistry' }],
      ebooksOrBlogs: [{ title: 'BioPharma Dive', url: 'https://www.biopharmadive.com/' }, { title: 'GEN', url: 'https://www.genengnews.com/' }]
    },
    {
      careerTitle: 'Forensic Scientist',
      description: 'Analyze evidence from crime scenes to help solve investigations.',
      relevanceJustification: 'Applied chemistry and biology in a legal context.',
      skillGaps: ['Forensic Pathology', 'Chain of Custody', 'Analytical Chemistry'],
      learningPath: [
        { step: 'Chemistry', recommendation: 'Master analytical chemistry.', details: 'Spectroscopy, Chromatography.' },
        { step: 'Legal', recommendation: 'Understand criminal procedure.', details: 'Evidence handling.' },
        { step: 'Intern', recommendation: 'Intern with local police lab.', details: 'Real-world exposure.' }
      ],
      youtubeTutorials: [{ title: 'Forensic Science', url: 'https://youtu.be/0B0B0B0B0B0' }, { title: 'CSI Real Life', url: 'https://youtu.be/1C1C1C1C1C1' }],
      freeCourses: [{ title: 'FutureLearn - Forensics', url: 'https://www.futurelearn.com/courses/introduction-to-forensic-science' }, { title: 'Coursera - Intro to Forensics', url: 'https://www.coursera.org/learn/forensic-science' }],
      ebooksOrBlogs: [{ title: 'Forensic Magazine', url: 'https://www.forensicmag.com/' }, { title: 'AAFS', url: 'https://www.aafs.org/' }]
    },
    {
      careerTitle: 'Lab Manager',
      description: 'Oversee the operations, safety, and administration of a scientific laboratory.',
      relevanceJustification: 'For scientists with strong organizational and leadership skills.',
      skillGaps: ['Inventory Management', 'Safety Compliance (OSHA)', 'Team Leadership'],
      learningPath: [
        { step: 'Safety', recommendation: 'Get certified in Lab Safety.', details: 'Critical for operation.' },
        { step: 'Admin', recommendation: 'Learn inventory software.', details: 'LIMS (Lab Information Management Systems).' },
        { step: 'People', recommendation: 'Management training.', details: 'Leading research teams.' }
      ],
      youtubeTutorials: [{ title: 'Lab Safety', url: 'https://youtu.be/2D2D2D2D2D2' }, { title: 'Lab Management', url: 'https://youtu.be/3E3E3E3E3E3' }],
      freeCourses: [{ title: 'Coursera - Lab Quality Management', url: 'https://www.coursera.org/learn/laboratory-quality-management' }, { title: 'CDC Lab Training', url: 'https://www.cdc.gov/labtraining/index.html' }],
      ebooksOrBlogs: [{ title: 'Lab Manager Magazine', url: 'https://www.labmanager.com/' }, { title: 'Nature Lab Life', url: 'https://www.nature.com/collections/prbfkwmwBz' }]
    },
    {
      careerTitle: 'Quality Control Analyst',
      description: 'Ensure products meet quality standards in pharma, food, or manufacturing.',
      relevanceJustification: 'Uses analytical science to ensure safety and consistency.',
      skillGaps: ['GMP (Good Manufacturing Practice)', 'Statistical Process Control', 'SOP Writing'],
      learningPath: [
        { step: 'GMP', recommendation: 'Learn GMP guidelines.', details: 'Essential for pharma/food.' },
        { step: 'Stats', recommendation: 'Six Sigma Yellow Belt.', details: 'Process improvement stats.' },
        { step: 'Docs', recommendation: 'Practice writing SOPs.', details: 'Standard Operating Procedures.' }
      ],
      youtubeTutorials: [{ title: 'Quality Control Basics', url: 'https://youtu.be/4F4F4F4F4F4' }, { title: 'GMP Explained', url: 'https://youtu.be/5G5G5G5G5G5' }],
      freeCourses: [{ title: 'Coursera - Quality Control', url: 'https://www.coursera.org/learn/quality-control' }, { title: 'Alison - Quality Management', url: 'https://alison.com/course/quality-management-systems' }],
      ebooksOrBlogs: [{ title: 'Quality Digest', url: 'https://www.qualitydigest.com/' }, { title: 'ASQ', url: 'https://asq.org/' }]
    },
    {
      careerTitle: 'Geoscientist',
      description: 'Study the physical aspects of the Earth to aid in resource exploration or environmental protection.',
      relevanceJustification: 'Applied earth science for energy and environmental sectors.',
      skillGaps: ['GIS/Mapping', 'Seismology', 'Field Data Collection'],
      learningPath: [
        { step: 'Map', recommendation: 'Master ArcGIS.', details: 'Essential for spatial data.' },
        { step: 'Field', recommendation: 'Geological field camp.', details: 'Hands-on rock identification.' },
        { step: 'Data', recommendation: 'Learn Python for geodata.', details: 'Analyzing large datasets.' }
      ],
      youtubeTutorials: [{ title: 'GeologyHub', url: 'https://www.youtube.com/user/GeologyHub' }, { title: 'Atlas Pro', url: 'https://www.youtube.com/channel/UCz1oFxNrFLOXVCPyk8e8MJw' }],
      freeCourses: [{ title: 'Coursera - Planet Earth', url: 'https://www.coursera.org/learn/planet-earth' }, { title: 'edX - Geology', url: 'https://www.edx.org/course/geology' }],
      ebooksOrBlogs: [{ title: 'Geology.com', url: 'https://geology.com/' }, { title: 'Earth Magazine', url: 'https://www.earthmagazine.org/' }]
    }
  ],

  // 4. Commerce & Management
  commerce: [
    {
      careerTitle: 'Investment Banker',
      description: 'Help companies raise capital and advise on mergers and acquisitions.',
      relevanceJustification: 'High finance role for those with strong numerical and analytical skills.',
      skillGaps: ['Financial Modeling', 'Valuation', 'Advanced Excel'],
      learningPath: [
        { step: 'Model', recommendation: 'Learn to build a DCF model.', details: 'Discounted Cash Flow.' },
        { step: 'Excel', recommendation: 'Master Excel shortcuts.', details: 'Speed is everything.' },
        { step: 'Pitch', recommendation: 'Create pitch decks.', details: 'Presenting to clients.' }
      ],
      youtubeTutorials: [{ title: 'Mergers & Inquisitions', url: 'https://www.youtube.com/channel/UCFjS3a_YJb7f0i1v5w5_5w' }, { title: 'Aswath Damodaran', url: 'https://www.youtube.com/user/AswathDamodaran' }],
      freeCourses: [{ title: 'Coursera - Private Equity', url: 'https://www.coursera.org/learn/private-equity' }, { title: 'Corporate Finance Institute (Free)', url: 'https://corporatefinanceinstitute.com/collections/' }],
      ebooksOrBlogs: [{ title: 'Wall Street Oasis', url: 'https://www.wallstreetoasis.com/' }, { title: 'Financial Times', url: 'https://www.ft.com/' }]
    },
    {
      careerTitle: 'Chartered Accountant',
      description: 'Manage financial records, taxes, and audits for organizations.',
      relevanceJustification: 'The gold standard for accounting professionals.',
      skillGaps: ['Accounting Standards', 'Tax Law', 'Auditing'],
      learningPath: [
        { step: 'Study', recommendation: 'Enroll in CA/CPA program.', details: 'Professional qualification.' },
        { step: 'Intern', recommendation: 'Articleship at a firm.', details: 'Practical audit experience.' },
        { step: 'Tech', recommendation: 'Learn Accounting Software.', details: 'Tally, SAP, QuickBooks.' }
      ],
      youtubeTutorials: [{ title: 'CA CS CM', url: 'https://youtu.be/6H6H6H6H6H6' }, { title: 'Accounting Stuff', url: 'https://www.youtube.com/channel/UCz4c_5_5_5_5' }],
      freeCourses: [{ title: 'Coursera - Financial Accounting', url: 'https://www.coursera.org/learn/wharton-accounting' }, { title: 'edX - ACCA', url: 'https://www.edx.org/school/acca' }],
      ebooksOrBlogs: [{ title: 'Journal of Accountancy', url: 'https://www.journalofaccountancy.com/' }, { title: 'Going Concern', url: 'https://goingconcern.com/' }]
    },
    {
      careerTitle: 'Digital Marketing Manager',
      description: 'Plan and execute marketing campaigns across web, SEO/SEM, email, and social media.',
      relevanceJustification: 'Modern commerce relies heavily on digital presence.',
      skillGaps: ['SEO/SEM', 'Google Analytics', 'Content Strategy'],
      learningPath: [
        { step: 'Certify', recommendation: 'Google Digital Garage.', details: 'Fundamentals of Digital Marketing.' },
        { step: 'Analytics', recommendation: 'Master Google Analytics.', details: 'Measure campaign success.' },
        { step: 'Practice', recommendation: 'Run a small ad campaign.', details: 'Facebook or Google Ads.' }
      ],
      youtubeTutorials: [{ title: 'Neil Patel', url: 'https://www.youtube.com/user/neilpatel' }, { title: 'Ahrefs', url: 'https://www.youtube.com/channel/UCWquNQV8Y0_Z5_Z5_Z5' }],
      freeCourses: [{ title: 'HubSpot Academy', url: 'https://academy.hubspot.com/' }, { title: 'Google Skillshop', url: 'https://skillshop.withgoogle.com/' }],
      ebooksOrBlogs: [{ title: 'Moz Blog', url: 'https://moz.com/blog' }, { title: 'Search Engine Land', url: 'https://searchengineland.com/' }]
    },
    {
      careerTitle: 'Product Manager',
      description: 'Guide the success of a product and lead the cross-functional team that is responsible for improving it.',
      relevanceJustification: 'Mini-CEO role combining business, tech, and UX.',
      skillGaps: ['Agile/Scrum', 'User Research', 'Product Strategy'],
      learningPath: [
        { step: 'Framework', recommendation: 'Learn Agile methodologies.', details: 'Scrum, Kanban.' },
        { step: 'Users', recommendation: 'Conduct user interviews.', details: 'Understand customer pain points.' },
        { step: 'Roadmap', recommendation: 'Build a product roadmap.', details: 'Prioritize features.' }
      ],
      youtubeTutorials: [{ title: 'Product School', url: 'https://www.youtube.com/c/ProductSchoolSanFrancisco' }, { title: 'Exponent', url: 'https://www.youtube.com/c/Exponent' }],
      freeCourses: [{ title: 'Udacity - Product Manager', url: 'https://www.udacity.com/course/product-manager-nanodegree--nd036' }, { title: 'Coursera - Digital Product Management', url: 'https://www.coursera.org/learn/real-world-product-management' }],
      ebooksOrBlogs: [{ title: 'Mind the Product', url: 'https://www.mindtheproduct.com/' }, { title: 'Silicon Valley Product Group', url: 'https://svpg.com/' }]
    },
    {
      careerTitle: 'Human Resources Manager',
      description: 'Oversee recruiting, interviewing, and hiring of new staff; consult with top executives on strategic planning.',
      relevanceJustification: 'Managing the most important asset of a business: people.',
      skillGaps: ['Labor Laws', 'Conflict Resolution', 'HRIS Systems'],
      learningPath: [
        { step: 'People', recommendation: 'Study Organizational Behavior.', details: 'Psychology of groups.' },
        { step: 'Tech', recommendation: 'Learn Workday or BambooHR.', details: 'HR Management Systems.' },
        { step: 'Cert', recommendation: 'SHRM-CP.', details: 'Standard HR certification.' }
      ],
      youtubeTutorials: [{ title: 'HR Basics', url: 'https://youtu.be/7I7I7I7I7I7' }, { title: 'AIHR Digital', url: 'https://www.youtube.com/c/AIHRDigital' }],
      freeCourses: [{ title: 'Coursera - HR Management', url: 'https://www.coursera.org/specializations/human-resource-management' }, { title: 'LinkedIn Learning - HR', url: 'https://www.linkedin.com/learning/topics/human-resources' }],
      ebooksOrBlogs: [{ title: 'SHRM Blog', url: 'https://blog.shrm.org/' }, { title: 'HR Dive', url: 'https://www.hrdive.com/' }]
    },
    {
      careerTitle: 'Supply Chain Analyst',
      description: 'Analyze data to improve the supply chain, reducing costs and increasing efficiency.',
      relevanceJustification: 'Critical for operations and logistics.',
      skillGaps: ['Logistics', 'SQL/Tableau', 'ERP Systems'],
      learningPath: [
        { step: 'Flow', recommendation: 'Understand Supply Chain flows.', details: 'Procurement to Delivery.' },
        { step: 'Data', recommendation: 'Analyze logistics data.', details: 'Identify bottlenecks.' },
        { step: 'Tech', recommendation: 'Learn SAP SCM.', details: 'Enterprise standard.' }
      ],
      youtubeTutorials: [{ title: 'Supply Chain Secrets', url: 'https://youtu.be/8J8J8J8J8J8' }, { title: 'CSCMP', url: 'https://www.youtube.com/user/CSCMPHV' }],
      freeCourses: [{ title: 'edX - Supply Chain Management', url: 'https://www.edx.org/micromasters/mitx-supply-chain-management' }, { title: 'Coursera - Supply Chain Analytics', url: 'https://www.coursera.org/learn/supply-chain-analytics' }],
      ebooksOrBlogs: [{ title: 'Supply Chain Dive', url: 'https://www.supplychaindive.com/' }, { title: 'SCM World', url: 'https://www.scmworld.com/' }]
    },
    {
      careerTitle: 'Actuary',
      description: 'Analyze the financial costs of risk and uncertainty using mathematics, statistics, and financial theory.',
      relevanceJustification: 'Highest level of risk analysis, perfect for math-heavy commerce students.',
      skillGaps: ['Probability', 'Risk Modeling', 'Programming (R/Python)'],
      learningPath: [
        { step: 'Exams', recommendation: 'Pass Actuarial Exams.', details: 'P and FM exams first.' },
        { step: 'Code', recommendation: 'Learn R.', details: 'Statistical computing.' },
        { step: 'Excel', recommendation: 'Advanced Excel.', details: 'Modeling essential.' }
      ],
      youtubeTutorials: [{ title: 'Etched Actuarial', url: 'https://www.youtube.com/channel/UC999999999' }, { title: 'Actuary video', url: 'https://youtu.be/9K9K9K9K9K9' }],
      freeCourses: [{ title: 'Coursera - Introduction to Actuarial Science', url: 'https://www.coursera.org/learn/actuarial-science' }, { title: 'Khan Academy - Statistics', url: 'https://www.khanacademy.org/math/statistics-probability' }],
      ebooksOrBlogs: [{ title: 'The Actuary Magazine', url: 'https://www.theactuary.com/' }, { title: 'Society of Actuaries', url: 'https://www.soa.org/' }]
    },
    {
      careerTitle: 'Operations Manager',
      description: 'Oversee the production of goods and provision of services to ensure efficiency.',
      relevanceJustification: 'Core business function suitable for management graduates.',
      skillGaps: ['Lean Six Sigma', 'Budgeting', 'Process Improvement'],
      learningPath: [
        { step: 'Process', recommendation: 'Lean Six Sigma Green Belt.', details: 'Optimize workflows.' },
        { step: 'Finance', recommendation: 'Learn operational finance.', details: 'Managing budgets and P&L.' },
        { step: 'Tech', recommendation: 'ERP systems.', details: 'NetSuite or SAP.' }
      ],
      youtubeTutorials: [{ title: 'Operations Management', url: 'https://youtu.be/7a7a7a7a7a7' }, { title: 'Gemba Academy', url: 'https://www.youtube.com/user/gembaacademy' }],
      freeCourses: [{ title: 'Coursera - Operations Management', url: 'https://www.coursera.org/learn/operations-management' }, { title: 'edX - Operations Management', url: 'https://www.edx.org/course/operations-management' }],
      ebooksOrBlogs: [{ title: 'Operations Manager', url: 'https://www.operationsmanager.com/' }, { title: 'McKinsey Operations', url: 'https://www.mckinsey.com/business-functions/operations/our-insights' }]
    }
  ],

  // 5. Arts, Humanities & Social Sciences
  arts: [
    {
      careerTitle: 'UX Researcher',
      description: 'Understand user behaviors, needs, and motivations through observation techniques and feedback.',
      relevanceJustification: 'Applies psychology and sociology research methods to tech products.',
      skillGaps: ['User Interviews', 'Usability Testing', 'Data Analysis'],
      learningPath: [
        { step: 'Method', recommendation: 'Learn qualitative research.', details: 'Interviewing and synthesis.' },
        { step: 'Test', recommendation: 'Conduct usability tests.', details: 'Observe users using a product.' },
        { step: 'Portfolio', recommendation: 'Create a case study.', details: 'Showcase your findings.' }
      ],
      youtubeTutorials: [{ title: 'NNgroup', url: 'https://www.youtube.com/user/NNgroup' }, { title: 'CareerFoundry', url: 'https://www.youtube.com/channel/UC000000000' }],
      freeCourses: [{ title: 'Coursera - UX Research', url: 'https://www.coursera.org/learn/ux-research-at-scale' }, { title: 'Interaction Design Foundation (Free Articles)', url: 'https://www.interaction-design.org/' }],
      ebooksOrBlogs: [{ title: 'UX Collective', url: 'https://uxdesign.cc/' }, { title: 'Nielsen Norman Group', url: 'https://www.nngroup.com/' }]
    },
    {
      careerTitle: 'Content Strategist',
      description: 'Develop a content strategy based on a company\'s business objectives and a customer\'s or end user\'s needs.',
      relevanceJustification: 'Perfect for writers who can think strategically about communication.',
      skillGaps: ['SEO', 'Content Management Systems', 'Analytics'],
      learningPath: [
        { step: 'Audit', recommendation: 'Perform a content audit.', details: 'Analyze existing content.' },
        { step: 'SEO', recommendation: 'Learn on-page SEO.', details: 'Keyword research and intent.' },
        { step: 'Plan', recommendation: 'Create an editorial calendar.', details: 'Plan content delivery.' }
      ],
      youtubeTutorials: [{ title: 'Moz SEO', url: 'https://www.youtube.com/user/MozHQ' }, { title: 'HubSpot Marketing', url: 'https://www.youtube.com/user/HubSpot' }],
      freeCourses: [{ title: 'HubSpot Content Marketing', url: 'https://academy.hubspot.com/courses/content-marketing' }, { title: 'Google Analytics', url: 'https://analytics.google.com/analytics/academy/' }],
      ebooksOrBlogs: [{ title: 'Content Marketing Institute', url: 'https://contentmarketinginstitute.com/' }, { title: 'Copyblogger', url: 'https://copyblogger.com/' }]
    },
    {
      careerTitle: 'Policy Analyst',
      description: 'Influence government decisions by researching complex issues and drafting reports.',
      relevanceJustification: 'For political science and history majors who want impact.',
      skillGaps: ['Statistical Analysis', 'Policy Writing', 'Cost-Benefit Analysis'],
      learningPath: [
        { step: 'Write', recommendation: 'Practice policy briefs.', details: 'Concise, actionable memos.' },
        { step: 'Stats', recommendation: 'Learn SPSS or R.', details: 'Back arguments with data.' },
        { step: 'Intern', recommendation: 'Think Tank internship.', details: 'Brookings, Pew, etc.' }
      ],
      youtubeTutorials: [{ title: 'Think Tank Watch', url: 'https://youtu.be/0L0L0L0L0L0' }, { title: 'Public Policy', url: 'https://youtu.be/1M1M1M1M1M1' }],
      freeCourses: [{ title: 'Coursera - Public Policy', url: 'https://www.coursera.org/learn/public-policy' }, { title: 'edX - Policy Analysis', url: 'https://www.edx.org/course/policy-analysis' }],
      ebooksOrBlogs: [{ title: 'Wonkblog', url: 'https://www.washingtonpost.com/news/wonk/' }, { title: 'Brookings', url: 'https://www.brookings.edu/' }]
    },
    {
      careerTitle: 'Industrial-Organizational Psychologist',
      description: 'Apply psychological principles to the workplace to improve productivity and well-being.',
      relevanceJustification: 'Applied psychology in a business setting.',
      skillGaps: ['Psychometrics', 'Organizational Development', 'Data Analysis'],
      learningPath: [
        { step: 'Degree', recommendation: 'Masters usually required.', details: 'I/O Psychology.' },
        { step: 'Stats', recommendation: 'Advanced Statistics.', details: 'Analyzing employee data.' },
        { step: 'Consult', recommendation: 'Consulting projects.', details: 'Solve real company issues.' }
      ],
      youtubeTutorials: [{ title: 'SIOP', url: 'https://www.youtube.com/user/SIOPofficial' }, { title: 'Organizational Psych', url: 'https://youtu.be/2N2N2N2N2N2' }],
      freeCourses: [{ title: 'Coursera - Organizational Behavior', url: 'https://www.coursera.org/learn/organizational-behavior' }, { title: 'OpenYale - Psychology', url: 'https://oyc.yale.edu/psychology' }],
      ebooksOrBlogs: [{ title: 'IO at Work', url: 'https://www.ioatwork.com/' }, { title: 'Psychology Today', url: 'https://www.psychologytoday.com/' }]
    },
    {
      careerTitle: 'Public Relations Specialist',
      description: 'Manage the public image of an organization.',
      relevanceJustification: 'Uses communication and sociology to influence perception.',
      skillGaps: ['Media Relations', 'Crisis Communication', 'Social Media'],
      learningPath: [
        { step: 'Write', recommendation: 'Draft press releases.', details: 'AP Style.' },
        { step: 'Connect', recommendation: 'Build media lists.', details: 'Contacts in journalism.' },
        { step: 'Monitor', recommendation: 'Brand monitoring.', details: 'Track public sentiment.' }
      ],
      youtubeTutorials: [{ title: 'PR Council', url: 'https://www.youtube.com/user/prcouncil' }, { title: 'Spin Sucks', url: 'https://www.youtube.com/user/spinsucks' }],
      freeCourses: [{ title: 'Coursera - PR Strategy', url: 'https://www.coursera.org/learn/public-relations-strategy' }, { title: 'Muck Rack Academy', url: 'https://academy.muckrack.com/' }],
      ebooksOrBlogs: [{ title: 'PR Daily', url: 'https://www.prdaily.com/' }, { title: 'PR Week', url: 'https://www.prweek.com/' }]
    },
    {
      careerTitle: 'Instructional Designer',
      description: 'Create engaging learning experiences and materials.',
      relevanceJustification: 'Applies education theory and psychology to design training.',
      skillGaps: ['ADDIE Model', 'E-learning Tools (Articulate)', 'Adult Learning Theory'],
      learningPath: [
        { step: 'Theory', recommendation: 'Learn ADDIE.', details: 'Design framework.' },
        { step: 'Tool', recommendation: 'Master Storyline.', details: 'Create interactive modules.' },
        { step: 'Portfolio', recommendation: 'Build a mini-course.', details: 'Showcase your skills.' }
      ],
      youtubeTutorials: [{ title: 'Devlin Peck', url: 'https://www.youtube.com/c/DevlinPeck' }, { title: 'The IDOL Courses', url: 'https://www.youtube.com/channel/UC333333333' }],
      freeCourses: [{ title: 'LinkedIn Learning - Instructional Design', url: 'https://www.linkedin.com/learning/topics/instructional-design' }, { title: 'Coursera - Learning Technologies', url: 'https://www.coursera.org/learn/learning-technologies' }],
      ebooksOrBlogs: [{ title: 'The eLearning Coach', url: 'https://theelearningcoach.com/' }, { title: 'Learning Solutions', url: 'https://learningsolutionsmag.com/' }]
    },
    {
      careerTitle: 'Digital Journalist',
      description: 'Report news and stories using digital tools and platforms.',
      relevanceJustification: 'Modern storytelling for mass media students.',
      skillGaps: ['Multimedia Editing', 'Data Journalism', 'CMS'],
      learningPath: [
        { step: 'Data', recommendation: 'Learn Data Journalism.', details: 'Find stories in spreadsheets.' },
        { step: 'Edit', recommendation: 'Video/Audio editing.', details: 'Premiere / Audition.' },
        { step: 'Publish', recommendation: 'Start a Substack.', details: 'Build an audience directly.' }
      ],
      youtubeTutorials: [{ title: 'Vox', url: 'https://www.youtube.com/user/voxdotcom' }, { title: 'Journalism.co.uk', url: 'https://www.youtube.com/user/journalismnews' }],
      freeCourses: [{ title: 'Google News Initiative', url: 'https://newsinitiative.withgoogle.com/training/' }, { title: 'Coursera - Journalism', url: 'https://www.coursera.org/specializations/journalism' }],
      ebooksOrBlogs: [{ title: 'Nieman Lab', url: 'https://www.niemanlab.org/' }, { title: 'Columbia Journalism Review', url: 'https://www.cjr.org/' }]
    },
    {
      careerTitle: 'Archivist / Curator',
      description: 'Preserve and manage historical documents and artifacts.',
      relevanceJustification: 'Ideal for history graduates passionate about preservation.',
      skillGaps: ['Cataloging Systems', 'Preservation Techniques', 'Digital Archiving'],
      learningPath: [
        { step: 'Catalog', recommendation: 'Learn library systems.', details: 'Dewey/LoC classification.' },
        { step: 'Digitize', recommendation: 'Digital preservation.', details: 'Scanning and metadata.' },
        { step: 'Intern', recommendation: 'Museum volunteering.', details: 'Hands-on artifact handling.' }
      ],
      youtubeTutorials: [{ title: 'The British Museum', url: 'https://www.youtube.com/user/britishmuseum' }, { title: 'Museum Hack', url: 'https://www.youtube.com/channel/UC...' }],
      freeCourses: [{ title: 'FutureLearn - Museum Studies', url: 'https://www.futurelearn.com/courses/museum' }, { title: 'Coursera - Art & Culture', url: 'https://www.coursera.org/learn/art-culture-strategy' }],
      ebooksOrBlogs: [{ title: 'American Alliance of Museums', url: 'https://www.aam-us.org/' }, { title: 'The Archivist', url: 'https://www.archivists.org/' }]
    }
  ],

  // 6. Law
  law: [
    {
      careerTitle: 'Corporate Lawyer',
      description: 'Advise businesses on their legal rights, responsibilities, and obligations.',
      relevanceJustification: 'Combines legal expertise with business acumen.',
      skillGaps: ['Contract Drafting', 'Mergers & Acquisitions', 'Negotiation'],
      learningPath: [
        { step: 'Draft', recommendation: 'Practice contract drafting.', details: 'Precision is key.' },
        { step: 'Biz', recommendation: 'Understand business finance.', details: 'Read balance sheets.' },
        { step: 'Intern', recommendation: 'Clerkship at a firm.', details: 'Gain transaction experience.' }
      ],
      youtubeTutorials: [{ title: 'LegalEagle', url: 'https://www.youtube.com/channel/UCpa-Zb0ZcQjADBjhx5ZH5uw' }, { title: 'Law Shelf', url: 'https://www.youtube.com/user/LawShelf' }],
      freeCourses: [{ title: 'Coursera - Corporate Law', url: 'https://www.coursera.org/learn/corporate-commercial-law' }, { title: 'edX - Contract Law', url: 'https://www.edx.org/course/contract-law' }],
      ebooksOrBlogs: [{ title: 'Above the Law', url: 'https://abovethelaw.com/' }, { title: 'Law.com', url: 'https://www.law.com/' }]
    },
    {
      careerTitle: 'Legal Technology Specialist',
      description: 'Implement technology solutions to improve legal practice efficiency.',
      relevanceJustification: 'Emerging field for tech-savvy law graduates.',
      skillGaps: ['E-Discovery Tools', 'Legal AI', 'Project Management'],
      learningPath: [
        { step: 'Tech', recommendation: 'Learn E-Discovery.', details: 'Relativity certification.' },
        { step: 'Auto', recommendation: 'Document automation.', details: 'Contract Express or HotDocs.' },
        { step: 'Process', recommendation: 'Legal Project Management.', details: 'Optimize workflows.' }
      ],
      youtubeTutorials: [{ title: 'Legaltech News', url: 'https://www.youtube.com/channel/UC444444444' }, { title: 'Artificial Lawyer', url: 'https://www.artificiallawyer.com/' }],
      freeCourses: [{ title: 'Law Schools Global - Legal Tech', url: 'https://www.lawschoolsglobal.com/' }, { title: 'Coursera - AI and Law', url: 'https://www.coursera.org/learn/ai-law' }],
      ebooksOrBlogs: [{ title: 'Artificial Lawyer', url: 'https://www.artificiallawyer.com/' }, { title: 'Legal IT Insider', url: 'https://legaltechnology.com/' }]
    },
    {
      careerTitle: 'Intellectual Property (IP) Attorney',
      description: 'Protect clients\' inventions, trademarks, and creative works.',
      relevanceJustification: 'Often requires a background in science/engineering + law.',
      skillGaps: ['Patent Law', 'Technical Writing', 'Litigation'],
      learningPath: [
        { step: 'Bar', recommendation: 'Pass the Patent Bar.', details: 'Specific to IP law.' },
        { step: 'Tech', recommendation: 'Understand the tech.', details: 'Deep dive into client inventions.' },
        { step: 'Draft', recommendation: 'Write patent claims.', details: 'Highly technical legal writing.' }
      ],
      youtubeTutorials: [{ title: 'USPTO', url: 'https://www.youtube.com/user/USPTOvideo' }, { title: 'Patent Education', url: 'https://youtu.be/5P5P5P5P5P5' }],
      freeCourses: [{ title: 'Coursera - Intellectual Property', url: 'https://www.coursera.org/learn/intellectual-property-law' }, { title: 'WIPO Academy', url: 'https://www.wipo.int/academy/en/' }],
      ebooksOrBlogs: [{ title: 'IPWatchdog', url: 'https://www.ipwatchdog.com/' }, { title: 'Patently-O', url: 'https://patentlyo.com/' }]
    },
    {
      careerTitle: 'Compliance Officer',
      description: 'Ensure a company follows all external regulations and internal policies.',
      relevanceJustification: 'Crucial for finance, healthcare, and corporate law.',
      skillGaps: ['Regulatory Knowledge', 'Risk Assessment', 'Auditing'],
      learningPath: [
        { step: 'Rules', recommendation: 'Master industry regs.', details: 'GDPR, HIPAA, SOX.' },
        { step: 'Cert', recommendation: 'CCEP Certification.', details: 'Compliance & Ethics Pro.' },
        { step: 'Audit', recommendation: 'Internal auditing skills.', details: 'Checking for adherence.' }
      ],
      youtubeTutorials: [{ title: 'Compliance Crystal', url: 'https://youtu.be/6Q6Q6Q6Q6Q6' }, { title: 'SCCE', url: 'https://www.youtube.com/user/theSCCE' }],
      freeCourses: [{ title: 'Coursera - Regulatory Compliance', url: 'https://www.coursera.org/learn/regulatory-compliance' }, { title: 'edX - Risk Management', url: 'https://www.edx.org/course/risk-management' }],
      ebooksOrBlogs: [{ title: 'The FCPA Blog', url: 'https://fcpablog.com/' }, { title: 'Compliance Week', url: 'https://www.complianceweek.com/' }]
    },
    {
      careerTitle: 'Legal Analyst',
      description: 'Conduct research and draft legal documents to support lawyers.',
      relevanceJustification: 'Entry-level role for law grads not yet barred.',
      skillGaps: ['Legal Research (Westlaw)', 'Writing', 'Case Management'],
      learningPath: [
        { step: 'Research', recommendation: 'Master LexisNexis/Westlaw.', details: 'Efficient searching.' },
        { step: 'Write', recommendation: 'Drafting memos.', details: 'Summarize case law.' },
        { step: 'Org', recommendation: 'Case management software.', details: 'Clio practice.' }
      ],
      youtubeTutorials: [{ title: 'Paralegal Boot Camp', url: 'https://www.youtube.com/user/ParalegalBootCamp' }, { title: 'Legal Research', url: 'https://youtu.be/7R7R7R7R7R7' }],
      freeCourses: [{ title: 'Coursera - American Law', url: 'https://www.coursera.org/learn/american-law' }, { title: 'edX - Legal Studies', url: 'https://www.edx.org/learn/legal-studies' }],
      ebooksOrBlogs: [{ title: 'Lawyerist', url: 'https://lawyerist.com/' }, { title: 'Clio Blog', url: 'https://www.clio.com/blog/' }]
    },
    {
      careerTitle: 'Human Rights Advocate',
      description: 'Work with NGOs to protect and promote human rights globally.',
      relevanceJustification: 'Passion-driven law career focused on social justice.',
      skillGaps: ['International Law', 'Advocacy', 'Fundraising'],
      learningPath: [
        { step: 'Law', recommendation: 'Study International Human Rights Law.', details: 'UN Declarations.' },
        { step: 'Language', recommendation: 'Learn a second language.', details: 'Critical for field work.' },
        { step: 'Volunteer', recommendation: 'Work with Amnesty/HRW.', details: 'Gain field experience.' }
      ],
      youtubeTutorials: [{ title: 'Human Rights Watch', url: 'https://www.youtube.com/user/HumanRightsWatch' }, { title: 'Amnesty International', url: 'https://www.youtube.com/user/AmnestyInternational' }],
      freeCourses: [{ title: 'Coursera - International Law', url: 'https://www.coursera.org/learn/international-law-in-action' }, { title: 'edX - Human Rights', url: 'https://www.edx.org/learn/human-rights' }],
      ebooksOrBlogs: [{ title: 'Just Security', url: 'https://www.justsecurity.org/' }, { title: 'Opinio Juris', url: 'http://opiniojuris.org/' }]
    },
    {
      careerTitle: 'Cyber Lawyer',
      description: 'Deal with legal issues related to the internet, data privacy, and cybersecurity.',
      relevanceJustification: 'High-demand niche due to increasing cyber threats.',
      skillGaps: ['Data Privacy Laws (GDPR/CCPA)', 'Cybersecurity Basics', 'Tech Contracts'],
      learningPath: [
        { step: 'Privacy', recommendation: 'CIPP Certification.', details: 'Information Privacy Pro.' },
        { step: 'Tech', recommendation: 'Understand encryption/networks.', details: 'Basics of how IT works.' },
        { step: 'Law', recommendation: 'Study cybercrime statutes.', details: 'CFAA, etc.' }
      ],
      youtubeTutorials: [{ title: 'Data Privacy', url: 'https://youtu.be/8S8S8S8S8S8' }, { title: 'Cyber Law', url: 'https://youtu.be/9T9T9T9T9T9' }],
      freeCourses: [{ title: 'Coursera - Privacy Law', url: 'https://www.coursera.org/learn/privacy-law-data-protection' }, { title: 'FutureLearn - Cyber Security Law', url: 'https://www.futurelearn.com/courses/cyber-security-law' }],
      ebooksOrBlogs: [{ title: 'The Privacy Advisor', url: 'https://iapp.org/news/' }, { title: 'Krebs on Security', url: 'https://krebsonsecurity.com/' }]
    },
    {
      careerTitle: 'Family Lawyer',
      description: 'Manage legal issues between members of the same family, such as divorce or child custody.',
      relevanceJustification: 'Direct client-facing role requiring empathy and mediation skills.',
      skillGaps: ['Mediation', 'Negotiation', 'Child Welfare Law'],
      learningPath: [
        { step: 'Soft', recommendation: 'Conflict resolution training.', details: 'Handling emotional clients.' },
        { step: 'Law', recommendation: 'State-specific family codes.', details: 'Divorce and custody laws.' },
        { step: 'Practice', recommendation: 'Clerk for family court.', details: 'Understand judicial perspective.' }
      ],
      youtubeTutorials: [{ title: 'Family Law', url: 'https://youtu.be/8a8a8a8a8a8' }, { title: 'Mediation Skills', url: 'https://youtu.be/9b9b9b9b9b9' }],
      freeCourses: [{ title: 'Coursera - Negotiation', url: 'https://www.coursera.org/learn/negotiation' }, { title: 'edX - Child Rights', url: 'https://www.edx.org/learn/child-rights' }],
      ebooksOrBlogs: [{ title: 'Family Lawyer Magazine', url: 'https://familylawyermagazine.com/' }, { title: 'ABA Family Law', url: 'https://www.americanbar.org/groups/family_law/' }]
    }
  ],

  // 7. Agriculture & Veterinary Sciences
  agriculture: [
    {
      careerTitle: 'Precision Agriculture Specialist',
      description: 'Use technology like GPS and IoT to optimize farming efficiency.',
      relevanceJustification: 'Tech-forward farming for modern agriculture graduates.',
      skillGaps: ['GIS/GPS', 'Drone Operation', 'Data Analysis'],
      learningPath: [
        { step: 'Tech', recommendation: 'Learn GIS mapping.', details: 'ArcGIS for fields.' },
        { step: 'Drone', recommendation: 'Drone Pilot License.', details: 'Crop monitoring.' },
        { step: 'Data', recommendation: 'Analyze yield data.', details: 'Optimize inputs.' }
      ],
      youtubeTutorials: [{ title: 'Precision Ag', url: 'https://youtu.be/0U0U0U0U0U0' }, { title: 'Future of Farming', url: 'https://youtu.be/1V1V1V1V1V1' }],
      freeCourses: [{ title: 'Coursera - Sustainable Ag', url: 'https://www.coursera.org/learn/sustainable-agricultural-land-management' }, { title: 'AgriTech', url: 'https://www.futurelearn.com/courses/smart-agriculture' }],
      ebooksOrBlogs: [{ title: 'PrecisionAg', url: 'https://www.precisionag.com/' }, { title: 'AgFunder News', url: 'https://agfundernews.com/' }]
    },
    {
      careerTitle: 'Agricultural Economist',
      description: 'Analyze economic data to help farmers and governments make decisions.',
      relevanceJustification: 'Business side of farming.',
      skillGaps: ['Econometrics', 'Market Analysis', 'Policy'],
      learningPath: [
        { step: 'Econ', recommendation: 'Microeconomics mastery.', details: 'Market forces.' },
        { step: 'Stats', recommendation: 'Learn R or Stata.', details: 'Price modeling.' },
        { step: 'Trends', recommendation: 'Study commodity markets.', details: 'Futures and options.' }
      ],
      youtubeTutorials: [{ title: 'Ag Economics', url: 'https://youtu.be/2W2W2W2W2W2' }, { title: 'Commodity Trading', url: 'https://youtu.be/3X3X3X3X3X3' }],
      freeCourses: [{ title: 'Coursera - Ag Economics', url: 'https://www.coursera.org/learn/agriculture-economics-nature' }, { title: 'edX - Food Security', url: 'https://www.edx.org/course/food-security-sustainability' }],
      ebooksOrBlogs: [{ title: 'Farm Bureau', url: 'https://www.fb.org/' }, { title: 'USDA Reports', url: 'https://www.usda.gov/' }]
    },
    {
      careerTitle: 'Veterinary Technologist',
      description: 'Perform medical tests and help veterinarians diagnose and treat animals.',
      relevanceJustification: 'Advanced support role in veterinary medicine.',
      skillGaps: ['Lab Procedures', 'Animal Handling', 'Radiology'],
      learningPath: [
        { step: 'Cert', recommendation: 'Vet Tech Certification.', details: 'State dependent.' },
        { step: 'Lab', recommendation: 'Master lab equipment.', details: 'Bloodwork analyzers.' },
        { step: 'Care', recommendation: 'Critical care nursing.', details: 'Emergency triage.' }
      ],
      youtubeTutorials: [{ title: 'Vet Ranch', url: 'https://www.youtube.com/user/VetRanch' }, { title: 'Kelsey Beth Carpenter', url: 'https://www.youtube.com/user/KelseyBethCarpenter' }],
      freeCourses: [{ title: 'Coursera - Animal Behaviour', url: 'https://www.coursera.org/learn/animal-welfare' }, { title: 'edX - Veterinary Medicine', url: 'https://www.edx.org/learn/veterinary-medicine' }],
      ebooksOrBlogs: [{ title: 'Veterinary Practice News', url: 'https://www.veterinarypracticenews.com/' }, { title: 'DVM360', url: 'https://www.dvm360.com/' }]
    },
    {
      careerTitle: 'Food Scientist',
      description: 'Use chemistry and biology to improve food products and safety.',
      relevanceJustification: 'Applied science in the food industry.',
      skillGaps: ['Food Chemistry', 'HACCP', 'Sensory Evaluation'],
      learningPath: [
        { step: 'Safety', recommendation: 'HACCP Certification.', details: 'Food safety protocols.' },
        { step: 'Chem', recommendation: 'Study food additives.', details: 'Preservation and texture.' },
        { step: 'R&D', recommendation: 'Product development.', details: 'Creating new recipes.' }
      ],
      youtubeTutorials: [{ title: 'Food Science', url: 'https://youtu.be/4Y4Y4Y4Y4Y4' }, { title: 'IFT', url: 'https://www.youtube.com/user/IFTlive' }],
      freeCourses: [{ title: 'Coursera - Science of Gastronomy', url: 'https://www.coursera.org/learn/gastronomy' }, { title: 'FutureLearn - Food Safety', url: 'https://www.futurelearn.com/courses/food-safety' }],
      ebooksOrBlogs: [{ title: 'Food Technology Magazine', url: 'https://www.ift.org/news-and-publications/food-technology-magazine' }, { title: 'Food Dive', url: 'https://www.fooddive.com/' }]
    },
    {
      careerTitle: 'Agronomist',
      description: 'Experts in soil management and crop production.',
      relevanceJustification: 'Core role for increasing crop yields.',
      skillGaps: ['Soil Science', 'Pest Management', 'Plant Genetics'],
      learningPath: [
        { step: 'Soil', recommendation: 'Soil sampling techniques.', details: 'Nutrient analysis.' },
        { step: 'IPM', recommendation: 'Integrated Pest Management.', details: 'Sustainable control.' },
        { step: 'Cert', recommendation: 'Certified Crop Adviser.', details: 'CCA exam.' }
      ],
      youtubeTutorials: [{ title: 'Agronomy TV', url: 'https://www.youtube.com/user/AgronomyTV' }, { title: 'Soil Science', url: 'https://youtu.be/5Z5Z5Z5Z5Z5' }],
      freeCourses: [{ title: 'Coursera - Plants and People', url: 'https://www.coursera.org/learn/plants-people' }, { title: 'WageningenX', url: 'https://www.edx.org/school/wageningenx' }],
      ebooksOrBlogs: [{ title: 'Crops & Soils', url: 'https://dl.sciencesocieties.org/publications/cns' }, { title: 'RealAgriculture', url: 'https://www.realagriculture.com/' }]
    },
    {
      careerTitle: 'Horticulturist',
      description: 'Cultivate plants for food, comfort, and beauty.',
      relevanceJustification: 'Specialized plant care for gardens and greenhouses.',
      skillGaps: ['Plant Physiology', 'Landscape Design', 'Greenhouse Management'],
      learningPath: [
        { step: 'Prop', recommendation: 'Master propagation.', details: 'Cloning and seeds.' },
        { step: 'Design', recommendation: 'Landscape CAD.', details: 'Designing spaces.' },
        { step: 'Biz', recommendation: 'Nursery management.', details: 'Selling plants.' }
      ],
      youtubeTutorials: [{ title: 'Horticulture Ryan', url: 'https://www.youtube.com/channel/UC6a6a6a6a6a' }, { title: 'RHS', url: 'https://www.youtube.com/user/RoyalHorticulturalSo' }],
      freeCourses: [{ title: 'Coursera - Gardening', url: 'https://www.coursera.org/learn/garden-plants' }, { title: 'Longwood Gardens', url: 'https://longwoodgardens.org/education/online-learning' }],
      ebooksOrBlogs: [{ title: 'HortWeek', url: 'https://www.hortweek.com/' }, { title: 'Garden Design', url: 'https://www.gardendesign.com/' }]
    },
    {
      careerTitle: 'Conservation Scientist',
      description: 'Manage natural resources to ensure they are used responsibly.',
      relevanceJustification: 'Focus on forestry and land use.',
      skillGaps: ['Ecology', 'Forestry Management', 'Policy'],
      learningPath: [
        { step: 'Eco', recommendation: 'Study ecosystem services.', details: 'Value of nature.' },
        { step: 'Map', recommendation: 'GIS for land use.', details: 'Track deforestation.' },
        { step: 'Plan', recommendation: 'Management plans.', details: 'Sustainable harvest.' }
      ],
      youtubeTutorials: [{ title: 'Conservation International', url: 'https://www.youtube.com/user/ConservationDotOrg' }, { title: 'Forestry', url: 'https://youtu.be/7b7b7b7b7b7' }],
      freeCourses: [{ title: 'Coursera - Intro to Conservation', url: 'https://www.coursera.org/learn/conservation-biology' }, { title: 'National Geographic', url: 'https://www.nationalgeographic.org/education/' }],
      ebooksOrBlogs: [{ title: 'Mongabay', url: 'https://news.mongabay.com/' }, { title: 'Conservation Biology', url: 'https://conbio.org/' }]
    },
    {
      careerTitle: 'Food Safety Inspector',
      description: 'Inspect food processing facilities to ensure compliance with health laws.',
      relevanceJustification: 'Ensures public health through agricultural standards.',
      skillGaps: ['Food Law', 'Inspection Protocols', 'Microbiology'],
      learningPath: [
        { step: 'Law', recommendation: 'Study FDA/USDA codes.', details: 'Know the regulations.' },
        { step: 'Micro', recommendation: 'Food microbiology course.', details: 'Identify pathogens.' },
        { step: 'Cert', recommendation: 'HACCP Auditor.', details: 'Professional certification.' }
      ],
      youtubeTutorials: [{ title: 'Food Safety', url: 'https://youtu.be/4e4e4e4e4e4' }, { title: 'Inspector Training', url: 'https://youtu.be/5r5r5r5r5r5' }],
      freeCourses: [{ title: 'Alison - Food Hygiene', url: 'https://alison.com/course/food-safety-and-hygiene' }, { title: 'Coursera - Food Systems', url: 'https://www.coursera.org/learn/food-system' }],
      ebooksOrBlogs: [{ title: 'Food Safety News', url: 'https://www.foodsafetynews.com/' }, { title: 'FDA Blog', url: 'https://www.fda.gov/news-events' }]
    }
  ],

  // 8. Design, Architecture & Fine Arts
  design: [
    {
      careerTitle: 'UI/UX Designer',
      description: 'Design intuitive and beautiful digital interfaces for apps and websites.',
      relevanceJustification: 'Natural transition for graphic designers into tech.',
      skillGaps: ['Figma', 'Prototyping', 'User Research'],
      learningPath: [
        { step: 'Tool', recommendation: 'Master Figma.', details: 'Industry standard.' },
        { step: 'Flow', recommendation: 'User flows.', details: 'Mapping the journey.' },
        { step: 'Build', recommendation: 'Design a mobile app.', details: 'Portfolio piece.' }
      ],
      youtubeTutorials: [{ title: 'DesignCourse', url: 'https://www.youtube.com/user/DesignCourse' }, { title: 'The Futur', url: 'https://www.youtube.com/user/TheSkoolRocks' }],
      freeCourses: [{ title: 'Google UX Certificate', url: 'https://grow.google/certificates/ux-design/' }, { title: 'HackDesign', url: 'https://hackdesign.org/' }],
      ebooksOrBlogs: [{ title: 'UX Planet', url: 'https://uxplanet.org/' }, { title: 'Muzli', url: 'https://muz.li/' }]
    },
    {
      careerTitle: 'Architectural Technologist',
      description: 'Focus on the technical design and construction details of buildings.',
      relevanceJustification: 'Bridge between design concept and construction reality.',
      skillGaps: ['Revit (BIM)', 'Construction Codes', 'Detailing'],
      learningPath: [
        { step: 'BIM', recommendation: 'Learn Revit.', details: 'Building Information Modeling.' },
        { step: 'Code', recommendation: 'Study building codes.', details: 'Safety compliance.' },
        { step: 'Tech', recommendation: 'Construction materials.', details: 'How things fit together.' }
      ],
      youtubeTutorials: [{ title: 'The B1M', url: 'https://www.youtube.com/user/TheB1M' }, { title: 'Revit Tutorials', url: 'https://www.youtube.com/user/BalkanArchitect' }],
      freeCourses: [{ title: 'LinkedIn Learning - Revit', url: 'https://www.linkedin.com/learning/topics/revit' }, { title: 'Coursera - Architecture', url: 'https://www.coursera.org/learn/making-architecture' }],
      ebooksOrBlogs: [{ title: 'ArchDaily', url: 'https://www.archdaily.com/' }, { title: 'Dezeen', url: 'https://www.dezeen.com/' }]
    },
    {
      careerTitle: 'Motion Graphics Designer',
      description: 'Create animated graphics for video, web, and social media.',
      relevanceJustification: 'Bringing static designs to life.',
      skillGaps: ['After Effects', 'Cinema 4D', 'Animation Principles'],
      learningPath: [
        { step: '2D', recommendation: 'Master After Effects.', details: 'Keyframing and easing.' },
        { step: '3D', recommendation: 'Learn Cinema 4D.', details: '3D integration.' },
        { step: 'Principle', recommendation: '12 Principles of Animation.', details: 'Disney rules.' }
      ],
      youtubeTutorials: [{ title: 'Ben Marriott', url: 'https://www.youtube.com/user/benmarriott' }, { title: 'School of Motion', url: 'https://www.youtube.com/channel/UCO1g-W2Uu4j_dE2-X_YcM7A' }],
      freeCourses: [{ title: 'Video Copilot', url: 'https://www.videocopilot.net/' }, { title: 'Skillshare - Motion Graphics', url: 'https://www.skillshare.com/browse/motion-graphics' }],
      ebooksOrBlogs: [{ title: 'Motionographer', url: 'https://motionographer.com/' }, { title: 'Lesterbanks', url: 'https://lesterbanks.com/' }]
    },
    {
      careerTitle: 'Fashion Merchandiser',
      description: 'Plan and promote fashion products to maximize sales.',
      relevanceJustification: 'Business side of fashion.',
      skillGaps: ['Retail Math', 'Trend Forecasting', 'Excel'],
      learningPath: [
        { step: 'Trend', recommendation: 'Follow WGSN.', details: 'Trend forecasting service.' },
        { step: 'Math', recommendation: 'Learn buying metrics.', details: 'Open to Buy, Sell-through.' },
        { step: 'Sheet', recommendation: 'Excel for inventory.', details: 'Managing stock levels.' }
      ],
      youtubeTutorials: [{ title: 'Fashion Buying', url: 'https://youtu.be/8c8c8c8c8c8' }, { title: 'Business of Fashion', url: 'https://www.youtube.com/user/BusinessofFashion' }],
      freeCourses: [{ title: 'Coursera - Fashion Management', url: 'https://www.coursera.org/learn/fashion-management' }, { title: 'FutureLearn - Fashion Business', url: 'https://www.futurelearn.com/courses/fashion-business' }],
      ebooksOrBlogs: [{ title: 'The Business of Fashion', url: 'https://www.businessoffashion.com/' }, { title: 'WWD', url: 'https://wwd.com/' }]
    },
    {
      careerTitle: 'Interior Designer',
      description: 'Plan and furnish internal spaces for safety, aesthetics, and function.',
      relevanceJustification: 'Designing spaces for people.',
      skillGaps: ['SketchUp', 'Material Sourcing', 'Building Systems'],
      learningPath: [
        { step: '3D', recommendation: 'Learn SketchUp.', details: 'Quick visualization.' },
        { step: 'Render', recommendation: 'V-Ray or Enscape.', details: 'Photorealistic rendering.' },
        { step: 'Source', recommendation: 'Build vendor list.', details: 'Furniture and fabrics.' }
      ],
      youtubeTutorials: [{ title: 'Interior Design Hub', url: 'https://www.youtube.com/channel/UC999999999' }, { title: 'Architectural Digest', url: 'https://www.youtube.com/user/ArchitecturalDigest' }],
      freeCourses: [{ title: 'MasterClass - Kelly Wearstler', url: 'https://www.masterclass.com/classes/kelly-wearstler-teaches-interior-design' }, { title: 'Skillshare - Interior Design', url: 'https://www.skillshare.com/browse/interior-design' }],
      ebooksOrBlogs: [{ title: 'Apartment Therapy', url: 'https://www.apartmenttherapy.com/' }, { title: 'Design Milk', url: 'https://design-milk.com/' }]
    },
    {
      careerTitle: 'Game Artist',
      description: 'Create 2D/3D art for video games.',
      relevanceJustification: 'High-growth entertainment industry.',
      skillGaps: ['Maya/Blender', 'Unreal Engine', 'Character Design'],
      learningPath: [
        { step: 'Model', recommendation: 'Learn Blender.', details: 'Low poly modeling.' },
        { step: 'Engine', recommendation: 'Import to Unreal/Unity.', details: 'See assets in game.' },
        { step: 'Texture', recommendation: 'Substance Painter.', details: 'Texturing assets.' }
      ],
      youtubeTutorials: [{ title: 'GDC', url: 'https://www.youtube.com/channel/UC0JB7TSe49lg56u6qH8y_MQ' }, { title: 'FlippedNormals', url: 'https://www.youtube.com/user/FlippedNormals' }],
      freeCourses: [{ title: 'Coursera - Game Design', url: 'https://www.coursera.org/specializations/game-design' }, { title: 'Unreal Learning', url: 'https://www.unrealengine.com/en-US/learn' }],
      ebooksOrBlogs: [{ title: '80 Level', url: 'https://80.lv/' }, { title: 'Polycount', url: 'https://polycount.com/' }]
    },
    {
      careerTitle: 'Art Director',
      description: 'Oversee the visual style and imagery in magazines, newspapers, product packaging, and productions.',
      relevanceJustification: 'Leadership role for experienced creatives.',
      skillGaps: ['Leadership', 'Project Management', 'Concept Development'],
      learningPath: [
        { step: 'Lead', recommendation: 'Manage a small team.', details: 'Delegate tasks.' },
        { step: 'Pitch', recommendation: 'Present concepts.', details: 'Sell ideas to clients.' },
        { step: 'Vision', recommendation: 'Develop mood boards.', details: 'Set the visual tone.' }
      ],
      youtubeTutorials: [{ title: 'The Futur', url: 'https://www.youtube.com/user/TheSkoolRocks' }, { title: 'Art Direction', url: 'https://youtu.be/0d0d0d0d0d0' }],
      freeCourses: [{ title: 'Domestika - Art Direction', url: 'https://www.domestika.org/en/courses/area/13-art-direction' }, { title: 'Skillshare - Creative Direction', url: 'https://www.skillshare.com/classes/Creative-Direction' }],
      ebooksOrBlogs: [{ title: 'It’s Nice That', url: 'https://www.itsnicethat.com/' }, { title: 'Communication Arts', url: 'https://www.commarts.com/' }]
    },
    {
      careerTitle: 'Set Designer',
      description: 'Design sets for plays, movies, and television productions.',
      relevanceJustification: 'Spatial design for storytelling.',
      skillGaps: ['Drafting', 'Model Making', 'History of Architecture'],
      learningPath: [
        { step: 'Draft', recommendation: 'Learn CAD drafting.', details: 'Technical plans.' },
        { step: 'Model', recommendation: 'Physical model making.', details: 'Scale representations.' },
        { step: 'History', recommendation: 'Study period styles.', details: 'Accuracy in design.' }
      ],
      youtubeTutorials: [{ title: 'National Theatre', url: 'https://www.youtube.com/user/NationalTheatre' }, { title: 'Academy Originals', url: 'https://www.youtube.com/user/AcademyOriginals' }],
      freeCourses: [{ title: 'Coursera - Theatre Design', url: 'https://www.coursera.org/learn/theatre-design' }, { title: 'MasterClass - Es Devlin', url: 'https://www.masterclass.com/classes/es-devlin-teaches-turning-ideas-into-art' }],
      ebooksOrBlogs: [{ title: 'Live Design', url: 'https://www.livedesignonline.com/' }, { title: 'Stage Directions', url: 'https://stage-directions.com/' }]
    }
  ],

  // 9. Computer Applications & IT
  computer_it: [
    {
      careerTitle: 'Full Stack Developer',
      description: 'Build both client-side and server-side software.',
      relevanceJustification: 'The most versatile role in software development.',
      skillGaps: ['React/Vue', 'Node.js', 'Databases (SQL/NoSQL)'],
      learningPath: [
        { step: 'Frontend', recommendation: 'Master React.', details: 'Component-based UI.' },
        { step: 'Backend', recommendation: 'Learn Express.js.', details: 'API development.' },
        { step: 'DB', recommendation: 'Connect MongoDB.', details: 'Store application data.' }
      ],
      youtubeTutorials: [{ title: 'Traversy Media', url: 'https://www.youtube.com/user/TechGuyWeb' }, { title: 'Web Dev Simplified', url: 'https://www.youtube.com/channel/UCFbNIlppjAuEX4znoulh0Cw' }],
      freeCourses: [{ title: 'Full Stack Open', url: 'https://fullstackopen.com/en/' }, { title: 'The Odin Project', url: 'https://www.theodinproject.com/' }],
      ebooksOrBlogs: [{ title: 'CSS-Tricks', url: 'https://css-tricks.com/' }, { title: 'Smashing Magazine', url: 'https://www.smashingmagazine.com/' }]
    },
    {
      careerTitle: 'DevOps Engineer',
      description: 'Bridge the gap between development and operations to deploy software faster.',
      relevanceJustification: 'Critical for modern software delivery.',
      skillGaps: ['Docker/Kubernetes', 'CI/CD (Jenkins/GitHub Actions)', 'AWS'],
      learningPath: [
        { step: 'Container', recommendation: 'Learn Docker.', details: 'Pack applications.' },
        { step: 'Orchestrate', recommendation: 'Learn Kubernetes.', details: 'Manage containers.' },
        { step: 'Pipeline', recommendation: 'Build CI/CD.', details: 'Automate deployment.' }
      ],
      youtubeTutorials: [{ title: 'TechWorld with Nana', url: 'https://www.youtube.com/channel/UCdngmbVKX1Tgre699-XLlUA' }, { title: 'DevOps Directive', url: 'https://www.youtube.com/channel/UCyL1_pYq9e8s_i_Tk-k_k_k' }],
      freeCourses: [{ title: 'KodeKloud (Free labs)', url: 'https://kodekloud.com/' }, { title: 'edX - DevOps', url: 'https://www.edx.org/learn/devops' }],
      ebooksOrBlogs: [{ title: 'DevOps.com', url: 'https://devops.com/' }, { title: 'Google SRE Book', url: 'https://sre.google/books/' }]
    },
    {
      careerTitle: 'Cybersecurity Specialist',
      description: 'Protect networks and data from cyber attacks.',
      relevanceJustification: 'High demand security role.',
      skillGaps: ['Network Security', 'Ethical Hacking', 'Linux'],
      learningPath: [
        { step: 'Net', recommendation: 'CompTIA Network+.', details: 'Understand networking.' },
        { step: 'Sec', recommendation: 'CompTIA Security+.', details: 'Baseline security.' },
        { step: 'Hack', recommendation: 'TryHackMe.', details: 'Practice labs.' }
      ],
      youtubeTutorials: [{ title: 'NetworkChuck', url: 'https://www.youtube.com/user/NetworkChuck' }, { title: 'John Hammond', url: 'https://www.youtube.com/user/RootOfTheNull' }],
      freeCourses: [{ title: 'Hack The Box Academy', url: 'https://academy.hackthebox.com/' }, { title: 'Cybrary', url: 'https://www.cybrary.it/' }],
      ebooksOrBlogs: [{ title: 'The Hacker News', url: 'https://thehackernews.com/' }, { title: 'Dark Reading', url: 'https://www.darkreading.com/' }]
    },
    {
      careerTitle: 'Cloud Engineer',
      description: 'Design and manage cloud infrastructure.',
      relevanceJustification: 'IT infrastructure is moving to the cloud.',
      skillGaps: ['AWS/Azure', 'Terraform', 'Linux'],
      learningPath: [
        { step: 'Cert', recommendation: 'AWS Solutions Architect.', details: 'Associate level.' },
        { step: 'IaC', recommendation: 'Learn Terraform.', details: 'Infrastructure as Code.' },
        { step: 'Script', recommendation: 'Learn Bash/Python.', details: 'Automation.' }
      ],
      youtubeTutorials: [{ title: 'Amazon Web Services', url: 'https://www.youtube.com/user/AmazonWebServices' }, { title: 'Azure Academy', url: 'https://www.youtube.com/channel/UC-lJ4h3_3q5q5_5_5_5' }],
      freeCourses: [{ title: 'AWS Skill Builder', url: 'https://explore.skillbuilder.aws/' }, { title: 'Microsoft Learn', url: 'https://docs.microsoft.com/en-us/learn/' }],
      ebooksOrBlogs: [{ title: 'Cloud Academy Blog', url: 'https://cloudacademy.com/blog/' }, { title: 'A Cloud Guru', url: 'https://acloudguru.com/blog' }]
    },
    {
      careerTitle: 'Mobile App Developer',
      description: 'Create applications for iOS and Android devices.',
      relevanceJustification: 'Ubiquity of smartphones.',
      skillGaps: ['Swift (iOS) or Kotlin (Android)', 'Flutter/React Native', 'UI Design'],
      learningPath: [
        { step: 'Native', recommendation: 'Learn Swift.', details: 'For iOS dev.' },
        { step: 'Cross', recommendation: 'Learn Flutter.', details: 'Build for both.' },
        { step: 'Publish', recommendation: 'Release on App Store.', details: 'Full lifecycle.' }
      ],
      youtubeTutorials: [{ title: 'CodeWithChris', url: 'https://www.youtube.com/user/CodeWithChris' }, { title: 'Android Developers', url: 'https://www.youtube.com/user/androiddevelopers' }],
      freeCourses: [{ title: 'Udacity - Android Basics', url: 'https://www.udacity.com/course/android-basics-nanodegree-by-google--nd803' }, { title: 'Stanford CS193p', url: 'https://cs193p.sites.stanford.edu/' }],
      ebooksOrBlogs: [{ title: 'RayWenderlich', url: 'https://www.raywenderlich.com/' }, { title: 'Android Weekly', url: 'https://androidweekly.net/' }]
    },
    {
      careerTitle: 'QA Automation Engineer',
      description: 'Write code to automatically test software for bugs.',
      relevanceJustification: 'Ensures software quality at speed.',
      skillGaps: ['Selenium/Cypress', 'Java/Python', 'CI/CD'],
      learningPath: [
        { step: 'Tool', recommendation: 'Learn Selenium.', details: 'Browser automation.' },
        { step: 'Framework', recommendation: 'Learn TestNG/JUnit.', details: 'Testing framework.' },
        { step: 'Pipe', recommendation: 'Integrate in Jenkins.', details: 'Automated runs.' }
      ],
      youtubeTutorials: [{ title: 'Automation Step by Step', url: 'https://www.youtube.com/channel/UCTt7pyY-o0eltq14glaG5dg' }, { title: 'Guru99', url: 'https://www.youtube.com/user/guru99videos' }],
      freeCourses: [{ title: 'TestAutomationUniversity', url: 'https://testautomationuniversity.applitools.com/' }, { title: 'Udemy (Free) - QA', url: 'https://www.udemy.com/topic/quality-assurance/' }],
      ebooksOrBlogs: [{ title: 'Ministry of Testing', url: 'https://www.ministryoftesting.com/' }, { title: 'Software Testing Help', url: 'https://www.softwaretestinghelp.com/' }]
    },
    {
      careerTitle: 'Database Administrator',
      description: 'Store and organize data using specialized software.',
      relevanceJustification: 'Guardians of the data.',
      skillGaps: ['Advanced SQL', 'Backup/Recovery', 'Performance Tuning'],
      learningPath: [
        { step: 'SQL', recommendation: 'Master T-SQL or PL/SQL.', details: 'Procedural SQL.' },
        { step: 'Admin', recommendation: 'Learn backups.', details: 'Disaster recovery.' },
        { step: 'Tune', recommendation: 'Query optimization.', details: 'Speed up DB.' }
      ],
      youtubeTutorials: [{ title: 'Brent Ozar', url: 'https://www.youtube.com/user/BrentOzarUnlimited' }, { title: 'Pinal Dave', url: 'https://www.youtube.com/user/pinaldave' }],
      freeCourses: [{ title: 'Oracle Dev Gym', url: 'https://devgym.oracle.com/' }, { title: 'Microsoft SQL Docs', url: 'https://docs.microsoft.com/en-us/sql/' }],
      ebooksOrBlogs: [{ title: 'SQLServerCentral', url: 'https://www.sqlservercentral.com/' }, { title: 'DBTA', url: 'https://www.dbta.com/' }]
    },
    {
      careerTitle: 'Network Engineer',
      description: 'Plan and implement computer networks.',
      relevanceJustification: 'The backbone of all IT infrastructure.',
      skillGaps: ['CCNA/CCNP', 'Routing & Switching', 'Network Security'],
      learningPath: [
        { step: 'Cert', recommendation: 'Cisco CCNA.', details: 'The gold standard.' },
        { step: 'Lab', recommendation: 'Packet Tracer labs.', details: 'Simulate networks.' },
        { step: 'Protocol', recommendation: 'Deep dive TCP/IP.', details: 'How data moves.' }
      ],
      youtubeTutorials: [{ title: 'NetworkChuck', url: 'https://www.youtube.com/user/NetworkChuck' }, { title: 'Jeremy\'s IT Lab', url: 'https://www.youtube.com/channel/UC0Q7HdlvZN41yJyLGkxjU2w' }],
      freeCourses: [{ title: 'Coursera - Computer Networking', url: 'https://www.coursera.org/learn/computer-networking' }, { title: 'Cybrary - Networking', url: 'https://www.cybrary.it/course/cisco-ccna/' }],
      ebooksOrBlogs: [{ title: 'Network World', url: 'https://www.networkworld.com/' }, { title: 'Packet Pushers', url: 'https://packetpushers.net/' }]
    }
  ],

  // 10. Education / Teaching / Training
  education: [
    {
      careerTitle: 'EdTech Product Specialist',
      description: 'Help develop and implement technology solutions for education.',
      relevanceJustification: 'Modernizing the classroom.',
      skillGaps: ['LMS Admin', 'Product Management', 'User Training'],
      learningPath: [
        { step: 'LMS', recommendation: 'Master Canvas/Moodle.', details: 'Learning Management Systems.' },
        { step: 'Product', recommendation: 'Agile basics.', details: 'Software dev process.' },
        { step: 'Train', recommendation: 'Create tutorials.', details: 'Help teachers use tech.' }
      ],
      youtubeTutorials: [{ title: 'EdSurge', url: 'https://www.youtube.com/user/EdSurge' }, { title: 'ISTE', url: 'https://www.youtube.com/user/istevideos' }],
      freeCourses: [{ title: 'Coursera - EdTech', url: 'https://www.coursera.org/specializations/virtual-teacher' }, { title: 'Google for Education', url: 'https://edu.google.com/teacher-center/' }],
      ebooksOrBlogs: [{ title: 'EdSurge', url: 'https://www.edsurge.com/' }, { title: 'eLearning Industry', url: 'https://elearningindustry.com/' }]
    },
    {
      careerTitle: 'Corporate Trainer',
      description: 'Teach employees new skills and strategies.',
      relevanceJustification: 'Teaching adults in a business setting.',
      skillGaps: ['Public Speaking', 'Facilitation', 'Needs Analysis'],
      learningPath: [
        { step: 'Speak', recommendation: 'Join Toastmasters.', details: 'Improve presentation.' },
        { step: 'Design', recommendation: 'Create a workshop.', details: 'Plan learning outcomes.' },
        { step: 'Cert', recommendation: 'CPTD Certification.', details: 'Talent Development.' }
      ],
      youtubeTutorials: [{ title: 'Train the Trainer', url: 'https://youtu.be/1e1e1e1e1e1e' }, { title: 'ATD', url: 'https://www.youtube.com/user/ASTD' }],
      freeCourses: [{ title: 'LinkedIn Learning - Corporate Training', url: 'https://www.linkedin.com/learning/topics/corporate-training' }, { title: 'Coursera - Teaching Adults', url: 'https://www.coursera.org/learn/teaching-adults' }],
      ebooksOrBlogs: [{ title: 'Training Industry', url: 'https://trainingindustry.com/' }, { title: 'ATD Blog', url: 'https://www.td.org/blog' }]
    },
    {
      careerTitle: 'Curriculum Developer',
      description: 'Design educational courses and materials.',
      relevanceJustification: 'The architect of learning.',
      skillGaps: ['Standards Alignment', 'Assessment Design', 'Writing'],
      learningPath: [
        { step: 'Map', recommendation: 'Curriculum mapping.', details: 'Align to state standards.' },
        { step: 'Assess', recommendation: 'Design rubrics.', details: 'Measuring success.' },
        { step: 'Digital', recommendation: 'Create digital assets.', details: 'Online textbooks.' }
      ],
      youtubeTutorials: [{ title: 'Curriculum Design', url: 'https://youtu.be/2f2f2f2f2f2f' }, { title: 'Education Week', url: 'https://www.youtube.com/user/EducationWeek' }],
      freeCourses: [{ title: 'Coursera - Curriculum Development', url: 'https://www.coursera.org/learn/teacher-curriculum' }, { title: 'Iris Center', url: 'https://iris.peabody.vanderbilt.edu/' }],
      ebooksOrBlogs: [{ title: 'Cult of Pedagogy', url: 'https://www.cultofpedagogy.com/' }, { title: 'Edutopia', url: 'https://www.edutopia.org/' }]
    },
    {
      careerTitle: 'Special Education Needs Coordinator',
      description: 'Coordinate support for students with special needs.',
      relevanceJustification: 'Specialized role requiring deep empathy and regulation knowledge.',
      skillGaps: ['IEP Management', 'Assistive Technology', 'Law'],
      learningPath: [
        { step: 'Law', recommendation: 'Study IDEA.', details: 'Disabilities Education Act.' },
        { step: 'Tech', recommendation: 'Learn assistive tech.', details: 'Text-to-speech, etc.' },
        { step: 'Plan', recommendation: 'Write IEPs.', details: 'Individualized Education Programs.' }
      ],
      youtubeTutorials: [{ title: 'Understood.org', url: 'https://www.youtube.com/user/understoodorg' }, { title: 'Special Ed Resource', url: 'https://youtu.be/3g3g3g3g3g3g' }],
      freeCourses: [{ title: 'Coursera - ADHD', url: 'https://www.coursera.org/learn/adhd-current-reality' }, { title: 'Autism Certification', url: 'https://ibcces.org/' }],
      ebooksOrBlogs: [{ title: 'Smart Kids with LD', url: 'https://www.smartkidswithld.org/' }, { title: 'Wrightslaw', url: 'https://www.wrightslaw.com/' }]
    },
    {
      careerTitle: 'Online Tutor / Coach',
      description: 'Provide personalized instruction remotely.',
      relevanceJustification: 'Flexible gig-economy teaching.',
      skillGaps: ['Online Whiteboards', 'Marketing', 'Zoom/Teams'],
      learningPath: [
        { step: 'Tech', recommendation: 'Master Zoom/Miro.', details: 'Virtual classroom tools.' },
        { step: 'Market', recommendation: 'Build a profile.', details: 'Wyzant, Superprof.' },
        { step: 'Niche', recommendation: 'Pick a specialty.', details: 'SAT Prep, Coding, etc.' }
      ],
      youtubeTutorials: [{ title: 'Online Teacher Dude', url: 'https://www.youtube.com/channel/UC44444444444' }, { title: 'VIPKid', url: 'https://www.youtube.com/user/thevipkid' }],
      freeCourses: [{ title: 'Udemy - Online Teaching', url: 'https://www.udemy.com/topic/online-teaching/' }, { title: 'Teachable', url: 'https://teachable.com/blog' }],
      ebooksOrBlogs: [{ title: 'The Online Teacher', url: 'https://theonlineteacher.blog/' }, { title: 'EdSurge', url: 'https://www.edsurge.com/' }]
    },
    {
      careerTitle: 'Education Policy Advisor',
      description: 'Advise on education legislation and reform.',
      relevanceJustification: 'Macro-level impact on schools.',
      skillGaps: ['Policy Analysis', 'Education Finance', 'Advocacy'],
      learningPath: [
        { step: 'Research', recommendation: 'Study education stats.', details: 'NCES data.' },
        { step: 'Write', recommendation: 'Draft policy briefs.', details: 'Influence lawmakers.' },
        { step: 'Network', recommendation: 'Join associations.', details: 'AERA, NEA.' }
      ],
      youtubeTutorials: [{ title: 'Education Policy', url: 'https://youtu.be/5h5h5h5h5h5' }, { title: 'TED Education', url: 'https://www.youtube.com/user/TEDEducation' }],
      freeCourses: [{ title: 'edX - Education Policy', url: 'https://www.edx.org/course/education-policy' }, { title: 'Coursera - US Education', url: 'https://www.coursera.org/learn/us-education-policy' }],
      ebooksOrBlogs: [{ title: 'Education Week', url: 'https://www.edweek.org/' }, { title: 'Chalkbeat', url: 'https://chalkbeat.org/' }]
    },
    {
      careerTitle: 'School Counselor',
      description: 'Help students develop academic and social skills.',
      relevanceJustification: 'Mental health and guidance focus.',
      skillGaps: ['Counseling Theory', 'Career Guidance', 'Crisis Intervention'],
      learningPath: [
        { step: 'Degree', recommendation: 'Masters in Counseling.', details: 'Licensure requirement.' },
        { step: 'Career', recommendation: 'Learn Holland Codes.', details: 'Career assessment.' },
        { step: 'Social', recommendation: 'SEL strategies.', details: 'Social Emotional Learning.' }
      ],
      youtubeTutorials: [{ title: 'ASCA', url: 'https://www.youtube.com/user/SCScene' }, { title: 'Counselor Keri', url: 'https://www.youtube.com/channel/UC666666666' }],
      freeCourses: [{ title: 'Coursera - School Counseling', url: 'https://www.coursera.org/specializations/school-counseling' }, { title: 'FutureLearn - Young People Mental Health', url: 'https://www.futurelearn.com/courses/young-people-mental-health' }],
      ebooksOrBlogs: [{ title: 'The Counseling Geek', url: 'https://www.thecounselinggeek.com/' }, { title: 'Elementary School Counselor', url: 'http://www.elementaryschoolcounselor.org/' }]
    },
    {
      careerTitle: 'Librarian / Media Specialist',
      description: 'Manage information resources and help students navigate digital literacy.',
      relevanceJustification: 'Crucial role in the information age.',
      skillGaps: ['Information Science', 'Digital Literacy', 'Database Management'],
      learningPath: [
        { step: 'Degree', recommendation: 'MLIS Degree.', details: 'Master of Library Science.' },
        { step: 'Tech', recommendation: 'Learn research databases.', details: 'JSTOR, EBSCO.' },
        { step: 'Teach', recommendation: 'Digital citizenship lessons.', details: 'Teaching students online safety.' }
      ],
      youtubeTutorials: [{ title: 'ALA', url: 'https://www.youtube.com/user/AmLibraryAssociation' }, { title: 'The Library', url: 'https://youtu.be/4g4g4g4g4g4' }],
      freeCourses: [{ title: 'Coursera - Media Literacy', url: 'https://www.coursera.org/learn/media-literacy' }, { title: 'edX - Information Science', url: 'https://www.edx.org/learn/library-science' }],
      ebooksOrBlogs: [{ title: 'American Libraries', url: 'https://americanlibrariesmagazine.org/' }, { title: 'School Library Journal', url: 'https://www.slj.com/' }]
    }
  ],

  // Fallback
  default: [
    {
      careerTitle: 'Digital Marketer',
      description: 'Use online channels to reach customers.',
      relevanceJustification: 'Applicable to almost any background.',
      skillGaps: ['Social Media', 'Content Creation', 'Analytics'],
      learningPath: [{ step: 'Cert', recommendation: 'Google Digital Garage.', details: 'Basics.' }],
      youtubeTutorials: [], freeCourses: [], ebooksOrBlogs: []
    },
    {
      careerTitle: 'Project Coordinator',
      description: 'Assist in managing projects.',
      relevanceJustification: 'General organizational role.',
      skillGaps: ['Scheduling', 'Communication', 'Office Suite'],
      learningPath: [{ step: 'Tool', recommendation: 'Learn Trello/Asana.', details: 'Task management.' }],
      youtubeTutorials: [], freeCourses: [], ebooksOrBlogs: []
    },
    {
      careerTitle: 'Sales Representative',
      description: 'Sell products or services.',
      relevanceJustification: 'Entry level business role.',
      skillGaps: ['Communication', 'Negotiation', 'CRM'],
      learningPath: [{ step: 'Read', recommendation: 'Influence by Cialdini.', details: 'Psychology of sales.' }],
      youtubeTutorials: [], freeCourses: [], ebooksOrBlogs: []
    },
    {
      careerTitle: 'Customer Support Specialist',
      description: 'Assist customers with issues.',
      relevanceJustification: 'Great starting point for tech/business.',
      skillGaps: ['Empathy', 'Troubleshooting', 'Writing'],
      learningPath: [{ step: 'Practice', recommendation: 'Mock emails.', details: 'Clear communication.' }],
      youtubeTutorials: [], freeCourses: [], ebooksOrBlogs: []
    },
    {
      careerTitle: 'Administrative Assistant',
      description: 'Support office operations.',
      relevanceJustification: 'Foundational business skills.',
      skillGaps: ['Microsoft Office', 'Organization', 'Scheduling'],
      learningPath: [{ step: 'Cert', recommendation: 'Microsoft Specialist.', details: 'Excel/Word.' }],
      youtubeTutorials: [], freeCourses: [], ebooksOrBlogs: []
    },
    {
      careerTitle: 'Freelance Writer',
      description: 'Write content for clients.',
      relevanceJustification: 'Flexible remote work.',
      skillGaps: ['Grammar', 'SEO', 'Self-discipline'],
      learningPath: [{ step: 'Write', recommendation: 'Start a blog.', details: 'Build portfolio.' }],
      youtubeTutorials: [], freeCourses: [], ebooksOrBlogs: []
    },
    {
      careerTitle: 'Social Media Manager',
      description: 'Manage brand presence online.',
      relevanceJustification: 'Creative and digital.',
      skillGaps: ['Graphics', 'Copywriting', 'Trends'],
      learningPath: [{ step: 'Design', recommendation: 'Canva basics.', details: 'Create posts.' }],
      youtubeTutorials: [], freeCourses: [], ebooksOrBlogs: []
    },
    {
      careerTitle: 'Data Entry Specialist',
      description: 'Input data into systems.',
      relevanceJustification: 'Entry level data role.',
      skillGaps: ['Typing Speed', 'Accuracy', 'Excel'],
      learningPath: [{ step: 'Practice', recommendation: 'Typing tests.', details: 'Improve speed.' }],
      youtubeTutorials: [], freeCourses: [], ebooksOrBlogs: []
    }
  ]
};
