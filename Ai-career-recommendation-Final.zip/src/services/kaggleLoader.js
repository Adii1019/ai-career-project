const Papa = require('papaparse');
function loadKaggleCsv(urlOrPath){return new Promise((resolve,reject)=>{Papa.parse(urlOrPath,{download:true,header:true,skipEmptyLines:true,complete:(res)=>resolve(res.data),error:(err)=>reject(err)});});}
async function loadAllKaggleSamples(names){const result={};for(const n of names){try{result[n]=await loadKaggleCsv('/data/kaggle/'+n);}catch(e){console.warn('Failed',n,e);result[n]=[];}}return result;}
module.exports={loadKaggleCsv,loadAllKaggleSamples};
