

import React, { useState, useMemo } from 'react';
import { UserType } from '../types';
import { BriefcaseIcon, SchoolIcon, UserIcon, MailIcon, LockIcon, EyeIcon, EyeOffIcon, CheckCircleIcon } from './icons';

interface SignUpProps {
  userType: UserType;
  onSignUp: (name: string, email: string, password: string) => Promise<void>;
  onNavigateToSignIn: () => void;
}

const SignUp: React.FC<SignUpProps> = ({ userType, onSignUp, onNavigateToSignIn }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const isStudent = userType === UserType.IN_EDUCATION;
  const title = isStudent ? "Create a Student Account" : "Create a Graduate Account";
  const Icon = isStudent ? SchoolIcon : BriefcaseIcon;
  const theme = {
    focusRing: isStudent ? 'focus:ring-blue-500' : 'focus:ring-green-500',
    buttonBg: isStudent ? 'bg-blue-600 hover:bg-blue-700' : 'bg-green-600 hover:bg-green-700',
    iconBg: isStudent ? 'bg-blue-100 dark:bg-blue-900/50' : 'bg-green-100 dark:bg-green-900/50',
    iconColor: isStudent ? 'text-blue-600 dark:text-blue-400' : 'text-green-600 dark:text-green-400',
    textColor: isStudent ? 'text-blue-600 hover:text-blue-500 dark:text-blue-400 dark:hover:text-blue-300' : 'text-green-600 hover:text-green-500 dark:text-green-400 dark:hover:text-green-300',
  };
  
  const passwordValidation = useMemo(() => {
    const validations = {
        length: password.length >= 8,
        uppercase: /[A-Z]/.test(password),
        lowercase: /[a-z]/.test(password),
        number: /\d/.test(password),
        specialChar: /[@$!%*?&]/.test(password),
    };
    const isValid = Object.values(validations).every(Boolean);
    return { ...validations, isValid };
  }, [password]);


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!passwordValidation.isValid) {
        setError("Please ensure your password meets all the requirements.");
        return;
    }
    setError(null);
    setIsLoading(true);
    try {
        await onSignUp(name, email, password);
    } catch(err: any) {
        setError(err.message);
    } finally {
        setIsLoading(false);
    }
  };
  
  const ValidationListItem: React.FC<{isValid: boolean; text: string}> = ({ isValid, text }) => (
    <li className={`flex items-center text-xs transition-colors ${isValid ? 'text-green-600 dark:text-green-400' : 'text-slate-500 dark:text-slate-400'}`}>
        <CheckCircleIcon className={`w-4 h-4 mr-2 ${isValid ? 'opacity-100' : 'opacity-30'}`} />
        {text}
    </li>
  );

  return (
    <div className="min-h-screen flex flex-col justify-center items-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-xl p-8">
            <div className="flex flex-col items-center text-center mb-8">
              <div className={`p-4 ${theme.iconBg} rounded-full mb-4`}>
                <Icon className={`w-10 h-10 ${theme.iconColor}`} />
              </div>
              <h2 className="text-2xl font-bold text-slate-800 dark:text-white">{title}</h2>
              <p className="text-slate-500 dark:text-slate-400 mt-1">Let's get you started on your career journey.</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
               <div>
                <label htmlFor="name" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Full Name</label>
                <div className="mt-1 relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                     <UserIcon className="h-5 w-5 text-slate-400" />
                  </div>
                  <input type="text" id="name" name="name" required value={name} onChange={e => setName(e.target.value)} className={`w-full pl-10 pr-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-2 ${theme.focusRing}`} placeholder="Jane Doe" />
                </div>
              </div>
              
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Email Address</label>
                <div className="mt-1 relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                     <MailIcon className="h-5 w-5 text-slate-400" />
                  </div>
                  <input type="email" id="email" name="email" required value={email} onChange={e => setEmail(e.target.value)} className={`w-full pl-10 pr-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-2 ${theme.focusRing}`} placeholder="you@example.com" />
                </div>
              </div>

              <div>
                <label htmlFor="password"className="block text-sm font-medium text-slate-700 dark:text-slate-300">Password</label>
                 <div className="mt-1 relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                     <LockIcon className="h-5 w-5 text-slate-400" />
                  </div>
                  <input type={showPassword ? 'text' : 'password'} id="password" name="password" required value={password} onChange={e => setPassword(e.target.value)} className={`w-full pl-10 pr-10 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-2 ${theme.focusRing}`} placeholder="••••••••" />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
                    {showPassword ? <EyeOffIcon className="h-5 w-5" /> : <EyeIcon className="h-5 w-5" />}
                  </button>
                </div>
                {password.length > 0 && (
                    <ul className="mt-2 space-y-1">
                        <ValidationListItem isValid={passwordValidation.length} text="At least 8 characters" />
                        <ValidationListItem isValid={passwordValidation.uppercase} text="Contains an uppercase letter" />
                        <ValidationListItem isValid={passwordValidation.lowercase} text="Contains a lowercase letter" />
                        <ValidationListItem isValid={passwordValidation.number} text="Contains a number" />
                        <ValidationListItem isValid={passwordValidation.specialChar} text="Contains a special character (@$!%*?&)" />
                    </ul>
                )}
              </div>

              {error && <p className="text-red-500 text-xs text-center">{error}</p>}
              
              <button type="submit" disabled={isLoading || !passwordValidation.isValid} className={`w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white ${theme.buttonBg} focus:outline-none focus:ring-2 focus:ring-offset-2 ${theme.focusRing} transition-colors disabled:opacity-50 disabled:cursor-not-allowed`}>
                {isLoading ? 'Creating Account...' : 'Create Account'}
              </button>
            </form>

             <p className="mt-6 text-center text-sm text-slate-500 dark:text-slate-400">
                Already have an account?{' '}
                <button onClick={onNavigateToSignIn} className={`font-medium ${theme.textColor}`}>
                    Sign In
                </button>
            </p>
        </div>
      </div>
    </div>
  );
};

export default SignUp;
