



import React, { useState } from 'react';
import { UserProfile } from '../types';
import { ArrowLeftIcon, SparklesIcon, MailIcon, SchoolIcon, CheckCircleIcon, UserIcon, LocationPinIcon, DownloadIcon, PhoneIcon, BriefcaseIcon, EditIcon, SaveIcon } from './icons';

declare var jspdf: any;
declare var html2canvas: any;

interface ResumeBuilderProps {
    profile: UserProfile;
    onProceed: (updatedProfile: UserProfile) => void;
    onBack: () => void;
}

const ResumeSectionRight: React.FC<{ title: string; icon: React.ReactNode; children: React.ReactNode }> = ({ title, icon, children }) => (
    <div className="mb-6">
        <h3 className="text-sm font-bold text-slate-700 dark:text-slate-200 uppercase tracking-wider pb-2 mb-3 flex items-center gap-3">
            {icon}
            {title}
        </h3>
        <div className="text-sm text-slate-600 dark:text-slate-300 space-y-2">
            {children}
        </div>
    </div>
);

const ResumeSectionLeft: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <div className="mb-6">
        <h3 className="text-sm font-bold text-slate-700 dark:text-slate-200 uppercase tracking-wider border-b-2 border-slate-300 dark:border-slate-500 pb-1 mb-3">
            {title}
        </h3>
        <div className="text-sm text-slate-600 dark:text-slate-300 space-y-2">
            {children}
        </div>
    </div>
);


const ResumeBuilder: React.FC<ResumeBuilderProps> = ({ profile, onProceed, onBack }) => {
  const [isEditing, setIsEditing] = useState(false);
  
  const getSubtitle = () => {
    const latestEducation = profile.educationHistory[profile.educationHistory.length - 1];
    if (latestEducation) {
        if (latestEducation.level === 'Doctorate / PhD') return `PhD Candidate in ${latestEducation.specialization || latestEducation.field}`;
        return `Student pursuing ${latestEducation.level} in ${latestEducation.specialization || latestEducation.field}`;
    }
    if (profile.education12thStream) return `High School Student (${profile.education12thStream} Stream)`;
    if (profile.dreamJobRoles) return `Aspiring ${profile.dreamJobRoles}`;
    return 'Student';
  };

  const [summary, setSummary] = useState('');
  const [objective, setObjective] = useState('');
  
  // Profile fields state for editing
  const [name, setName] = useState(profile.name);
  const [email, setEmail] = useState(profile.email);
  const [phone, setPhone] = useState(profile.phone);
  const [location, setLocation] = useState(profile.location);
  
  const [hardSkills, setHardSkills] = useState(profile.hardSkills || '');
  const [softSkills, setSoftSkills] = useState(profile.softSkills || '');
  const [toolsAndSoftware, setToolsAndSoftware] = useState(profile.toolsAndSoftware || '');
  const [internships, setInternships] = useState(profile.internships || '');
  const [projects, setProjects] = useState(profile.projects || '');
  const [languages, setLanguages] = useState(profile.languages || '');
  const [certifications, setCertifications] = useState(profile.certifications || '');
  
  const handleDownloadPdf = () => {
    const { jsPDF } = jspdf;
    const resumeElement = document.getElementById('resume-to-print');
    if (!resumeElement) {
        console.error("Resume element not found!");
        return;
    }

    const spinner = document.createElement('div');
    spinner.innerHTML = `<div class="fixed inset-0 bg-black/50 flex items-center justify-center z-50"><div class="text-white text-lg">Downloading PDF...</div></div>`;
    document.body.appendChild(spinner);

    html2canvas(resumeElement, { 
        scale: 2, 
        useCORS: true,
        logging: false,
     }).then(canvas => {
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF({
            orientation: 'portrait',
            unit: 'pt',
            format: 'a4'
        });
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
        
        pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
        pdf.save(`${profile.name.replace(' ', '_')}_Resume.pdf`);
        document.body.removeChild(spinner);
    }).catch(err => {
        console.error("Error generating PDF:", err);
        document.body.removeChild(spinner);
    });
  }
  
  const handleProceedClick = () => {
    const updatedProfile = {
        ...profile,
        name, email, phone, location,
        hardSkills,
        softSkills,
        toolsAndSoftware,
        internships,
        projects,
        languages,
        certifications
    };
    onProceed(updatedProfile);
  };

  const AIPoweredTextArea: React.FC<{ value: string; onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void; rows?: number; placeholder?: string }> = ({ value, onChange, rows = 3, placeholder = '' }) => (
    <textarea 
        value={value}
        onChange={onChange}
        rows={rows}
        placeholder={placeholder}
        disabled={!isEditing}
        className={`w-full text-sm transition-all duration-200 ${
            isEditing 
            ? 'bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 focus:ring-2 focus:ring-blue-500 rounded-md p-2' 
            : 'bg-transparent border-none focus:ring-0 p-0 m-0 resize-none text-slate-600 dark:text-slate-300 placeholder:text-slate-400 dark:placeholder:text-slate-500'
        }`}
    />
  );
  
  const EditableInput: React.FC<{ value: string; onChange: (e: React.ChangeEvent<HTMLInputElement>) => void; placeholder?: string }> = ({ value, onChange, placeholder = '' }) => (
     <input
        type="text"
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        disabled={!isEditing}
         className={`w-full text-sm transition-all duration-200 bg-transparent ${
            isEditing 
            ? 'border-b border-slate-300 focus:border-blue-500 outline-none' 
            : 'border-none p-0'
        }`}
     />
  );


  return (
    <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
             <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white sm:text-4xl text-center mb-4">Review & Finalize Your Resume</h1>
            <div className="relative bg-white dark:bg-slate-800 rounded-lg shadow-xl overflow-hidden group">
                {/* Edit Button */}
                <button 
                    onClick={() => setIsEditing(!isEditing)} 
                    className={`absolute top-4 right-4 z-10 p-2 rounded-full shadow-md transition-all duration-300 ${
                        isEditing 
                        ? 'bg-green-500 hover:bg-green-600 text-white' 
                        : 'bg-white dark:bg-slate-700 hover:bg-gray-100 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-300'
                    }`}
                    title={isEditing ? "Save Changes" : "Edit Resume"}
                >
                    {isEditing ? <SaveIcon className="w-5 h-5" /> : <EditIcon className="w-5 h-5" />}
                </button>
                
                <div id="resume-to-print" className="flex flex-col md:flex-row">
                    {/* Left Column */}
                    <div className="w-full md:w-1/3 bg-slate-50 dark:bg-slate-700 p-8">
                        <div className="flex justify-center mb-8">
                            <div className="w-32 h-32 bg-slate-300 dark:bg-slate-500 rounded-full flex items-center justify-center">
                                <UserIcon className="w-16 h-16 text-slate-500 dark:text-slate-300" />
                            </div>
                        </div>

                        <ResumeSectionLeft title="Contact">
                             <div className="flex items-start gap-2">
                                <MailIcon className="w-4 h-4 text-slate-500 dark:text-slate-400 shrink-0 mt-1" />
                                <EditableInput value={email} onChange={e => setEmail(e.target.value)} />
                            </div>
                            <div className="flex items-start gap-2">
                                <PhoneIcon className="w-4 h-4 text-slate-500 dark:text-slate-400 shrink-0 mt-1" />
                                <EditableInput value={phone} onChange={e => setPhone(e.target.value)} placeholder="Phone" />
                            </div>
                            <div className="flex items-start gap-2">
                                <LocationPinIcon className="w-4 h-4 text-slate-500 dark:text-slate-400 shrink-0 mt-1" />
                                <EditableInput value={location} onChange={e => setLocation(e.target.value)} placeholder="Location" />
                            </div>
                        </ResumeSectionLeft>
                        
                        <ResumeSectionLeft title="Technical Skills">
                            <AIPoweredTextArea value={hardSkills} onChange={e => setHardSkills(e.target.value)} rows={5} placeholder="e.g., HTML5, CSS3, JavaScript" />
                        </ResumeSectionLeft>
                        
                        <ResumeSectionLeft title="Soft Skills">
                            <AIPoweredTextArea value={softSkills} onChange={e => setSoftSkills(e.target.value)} rows={4} placeholder="e.g., Communication, Teamwork" />
                        </ResumeSectionLeft>

                        <ResumeSectionLeft title="Tools & Software">
                            <AIPoweredTextArea value={toolsAndSoftware} onChange={e => setToolsAndSoftware(e.target.value)} rows={4} placeholder="e.g., VS Code, Figma, Jira" />
                        </ResumeSectionLeft>

                        <ResumeSectionLeft title="Languages">
                            <AIPoweredTextArea value={languages} onChange={e => setLanguages(e.target.value)} rows={3} placeholder="e.g., English (Native), Spanish (Basic)" />
                        </ResumeSectionLeft>
                    </div>

                    {/* Right Column */}
                    <div className="w-full md:w-2/3 p-8">
                        <div className="pb-6 mb-6">
                             {isEditing ? (
                                <input type="text" value={name} onChange={e => setName(e.target.value)} className="text-4xl font-extrabold text-slate-800 dark:text-white bg-transparent border-b border-slate-300 focus:border-blue-500 outline-none w-full" />
                             ) : (
                                <h2 className="text-4xl font-extrabold text-slate-800 dark:text-white">{name}</h2>
                             )}
                            <p className="text-lg text-blue-600 dark:text-blue-400 mt-1">{getSubtitle()}</p>
                        </div>
                        
                        {(isEditing || summary) && (
                            <ResumeSectionRight title="Professional Summary" icon={<UserIcon className="w-5 h-5" />}>
                                <AIPoweredTextArea value={summary} onChange={e => setSummary(e.target.value)} placeholder="Write a brief professional summary..." />
                            </ResumeSectionRight>
                        )}

                        <ResumeSectionRight title="Career Objective" icon={<UserIcon className="w-5 h-5" />}>
                           <AIPoweredTextArea value={objective} onChange={e => setObjective(e.target.value)} placeholder="Seeking an entry-level position in the... industry. Eager to leverage my skills in... and academic background to contribute to a forward-thinking organization." />
                        </ResumeSectionRight>

                        <ResumeSectionRight title="Education" icon={<SchoolIcon className="w-5 h-5" />}>
                           {profile.educationHistory.map(entry => (
                                <div key={entry.id} className="mb-3">
                                    <div className="flex justify-between items-baseline">
                                        <p className="font-bold">{`${entry.level} in ${entry.specialization || entry.field}`}</p>
                                        <p className="text-xs text-slate-500 dark:text-slate-400">{entry.startYear} - {entry.endYear}</p>
                                    </div>
                                    {entry.institution && <p>{entry.institution}</p>}
                                    <p>Grade: {entry.grade}</p>
                                </div>
                            ))}
                            {profile.education12th && (
                                <div className="mb-3">
                                    <p className="font-bold">Higher Secondary School (12th Grade)</p>
                                     {profile.education12thSchool && <p>{profile.education12thSchool}</p>}
                                     <p>Stream: {profile.education12thStream}</p>
                                     <p>Percentage/CGPA: {profile.education12th}</p>
                                </div>
                            )}
                            {profile.education10th && (
                                <div>
                                    <p className="font-bold">Secondary School (10th Grade)</p>
                                    {profile.education10thSchool && <p>{profile.education10thSchool}</p>}
                                    <p>Percentage/CGPA: {profile.education10th}</p>
                                </div>
                            )}
                        </ResumeSectionRight>
                        
                        <ResumeSectionRight title="Internships & Work History" icon={<BriefcaseIcon className="w-5 h-5" />}>
                            <AIPoweredTextArea value={internships} onChange={e => setInternships(e.target.value)} rows={5} placeholder={`Company Name - Role\n- Describe your responsibilities and achievements.\n- Mention key projects and technologies used.`} />
                        </ResumeSectionRight>
                        
                        <ResumeSectionRight title="Projects" icon={<BriefcaseIcon className="w-5 h-5" />}>
                            <AIPoweredTextArea value={projects} onChange={e => setProjects(e.target.value)} rows={5} placeholder={`Project Title\n- Describe your project here. What was the goal? What technologies did you use?\n- Mention your key contributions and the outcome.`} />
                        </ResumeSectionRight>

                        <ResumeSectionRight title="Certifications" icon={<CheckCircleIcon className="w-5 h-5" />}>
                             <AIPoweredTextArea value={certifications} onChange={e => setCertifications(e.target.value)} rows={3} placeholder="e.g., AWS Certified Cloud Practitioner" />
                        </ResumeSectionRight>
                    </div>
                </div>
            </div>

            <div className="mt-8 flex flex-col sm:flex-row justify-between items-center gap-4">
                <button type="button" onClick={onBack} className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2 bg-slate-200 dark:bg-slate-600 text-slate-800 dark:text-slate-100 rounded-md hover:bg-slate-300 dark:hover:bg-slate-500 transition-colors">
                    <ArrowLeftIcon />
                    Back to Edit
                </button>
                <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
                    <button onClick={handleDownloadPdf} className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors font-semibold">
                        <DownloadIcon className="w-5 h-5"/>
                        Download as PDF
                    </button>
                    <button type="button" onClick={handleProceedClick} className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors font-semibold">
                        Confirm & Get Recommendations
                        <SparklesIcon />
                    </button>
                </div>
            </div>
        </div>
    </div>
  )
};

export default ResumeBuilder;
