
import React, { useState, useMemo } from 'react';
import { UserProfile, UserType, EducationEntry } from '../types';
import { ArrowLeftIcon, ArrowRightIcon, SparklesIcon, UploadIcon, BriefcaseIcon, CheckCircleIcon, TrashIcon, CompassIcon } from './icons';

interface AppData {
    quizQuestions: any;
    educationFields: any[];
    formStructureByField: any;
}
interface ProfileFormProps {
  userType: UserType;
  profile: UserProfile;
  setProfile: React.Dispatch<React.SetStateAction<UserProfile>>;
  onComplete: (profile: UserProfile) => void;
  error: string | null;
  appData: AppData;
}

const InputField: React.FC<{ label: string; name: string; value: string; onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void; placeholder: string; isTextArea?: boolean; type?: string }> = ({ label, name, value, onChange, placeholder, isTextArea = false, type = 'text' }) => (
  <div>
    <label htmlFor={name} className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{label}</label>
    {isTextArea ? (
      <textarea id={name} name={name} value={value} onChange={onChange} rows={3} className="w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder={placeholder} />
    ) : (
      <input type={type} id={name} name={name} value={value} onChange={onChange} className="w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder={placeholder} />
    )}
  </div>
);

const SelectField: React.FC<{ label: string; name: string; value: string; onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void; options: { value: string; label: string }[]; disabled?: boolean }> = ({ label, name, value, onChange, options, disabled=false }) => (
  <div>
    <label htmlFor={name} className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{label}</label>
    <select id={name} name={name} value={value} onChange={onChange} disabled={disabled} className="w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50">
      <option value="" disabled>Select...</option>
      {options.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
    </select>
  </div>
);

const educationLevelOptions = [
    // After 10th / Diploma / Certificate Options
    { value: 'Polytechnic Diploma', label: 'Polytechnic Diploma' },
    { value: 'ITI (Industrial Training Institute)', label: 'ITI (Industrial Training Institute)' },
    { value: 'Vocational Course', label: 'Vocational Course' },
    { value: 'Agriculture Studies', label: 'Agriculture Studies' },
    { value: 'Fine Arts Foundation', label: 'Fine Arts Foundation' },
    { value: 'Home Science', label: 'Home Science' },
    { value: 'Hotel Management Foundation', label: 'Hotel Management Foundation' },
    { value: 'Fashion Designing Foundation', label: 'Fashion Designing Foundation' },
    { value: 'Computer Operator / Basic IT Course', label: 'Computer Operator / Basic IT Course' },
    { value: 'Paramedical Certificate Course', label: 'Paramedical Certificate Course' },

    // After 12th / Undergraduate
    { value: 'Bachelor of Engineering / B.Tech', label: 'Bachelor of Engineering / B.Tech' },
    { value: 'Bachelor of Science (B.Sc)', label: 'Bachelor of Science (B.Sc)' },
    { value: 'Bachelor of Commerce (B.Com)', label: 'Bachelor of Commerce (B.Com)' },
    { value: 'Bachelor of Arts (B.A)', label: 'Bachelor of Arts (B.A)' },
    { value: 'Nursing (B.Sc Nursing / GNM)', label: 'Nursing (B.Sc Nursing / GNM)' },
    { value: 'BBA (Business Administration)', label: 'BBA (Business Administration)' },
    { value: 'BCA (Computer Applications)', label: 'BCA (Computer Applications)' },
    { value: 'MBBS / Medical Studies', label: 'MBBS / Medical Studies' },
    { value: 'Pharmacy (B.Pharm / D.Pharm)', label: 'Pharmacy (B.Pharm / D.Pharm)' },
    { value: 'Agriculture (B.Sc Agri)', label: 'Agriculture (B.Sc Agri)' },
    { value: 'Law (BA LLB / BBA LLB)', label: 'Law (BA LLB / BBA LLB)' },
    { value: 'Fashion Designing', label: 'Fashion Designing' },
    { value: 'Hotel Management', label: 'Hotel Management' },
    { value: 'Fine Arts (BFA)', label: 'Fine Arts (BFA)' },
    { value: 'Mass Media / Journalism', label: 'Mass Media / Journalism' },
    { value: 'Architecture (B.Arch)', label: 'Architecture (B.Arch)' },
    { value: 'Event Management', label: 'Event Management' },
    { value: 'Animation & Graphics', label: 'Animation & Graphics' },
    { value: 'Psychology', label: 'Psychology' },
    { value: 'Physiotherapy', label: 'Physiotherapy' },

    // Higher Education / Post-Graduation
    { value: "Master's Degree (MA / MCom / MSc)", label: "Master's Degree (MA / MCom / MSc)" },
    { value: 'MCA (Computer Applications)', label: 'MCA (Computer Applications)' },
    { value: 'MBA (Business Administration)', label: 'MBA (Business Administration)' },
    { value: 'M.Tech / ME', label: 'M.Tech / ME' },
    { value: 'Doctorate / PhD', label: 'Doctorate / PhD' },
    { value: 'Postgraduate Diploma', label: 'Postgraduate Diploma' },
    { value: 'Certificate Program', label: 'Certificate Program' },
    { value: 'Professional Course (CA / CS / CMA)', label: 'Professional Course (CA / CS / CMA)' },
    
    { value: "Other", label: "Other" },
];

const levelToFieldMapping: Record<string, string[]> = {
    // Diploma / Certificate
    'Polytechnic Diploma': ['Engineering & Technology', 'Computer Applications & IT', 'Design, Architecture & Fine Arts'],
    'ITI (Industrial Training Institute)': ['Engineering & Technology'],
    'Vocational Course': ['Engineering & Technology', 'Commerce & Management', 'Arts, Humanities & Social Sciences', 'Design, Architecture & Fine Arts', 'Medical & Health Sciences', 'Agriculture & Veterinary Sciences'],
    'Agriculture Studies': ['Agriculture & Veterinary Sciences'],
    'Fine Arts Foundation': ['Design, Architecture & Fine Arts'],
    'Home Science': ['Science (Pure & Applied)', 'Arts, Humanities & Social Sciences'],
    'Hotel Management Foundation': ['Commerce & Management'],
    'Fashion Designing Foundation': ['Design, Architecture & Fine Arts'],
    'Computer Operator / Basic IT Course': ['Computer Applications & IT'],
    'Paramedical Certificate Course': ['Medical & Health Sciences'],

    // Undergraduate
    'Bachelor of Engineering / B.Tech': ['Engineering & Technology', 'Computer Applications & IT', 'Agriculture & Veterinary Sciences'],
    'Bachelor of Science (B.Sc)': ['Science (Pure & Applied)', 'Medical & Health Sciences', 'Agriculture & Veterinary Sciences', 'Computer Applications & IT', 'Arts, Humanities & Social Sciences', 'Education / Teaching / Training'],
    'Bachelor of Commerce (B.Com)': ['Commerce & Management'],
    'Bachelor of Arts (B.A)': ['Arts, Humanities & Social Sciences', 'Law', 'Design, Architecture & Fine Arts', 'Education / Teaching / Training', 'Commerce & Management', 'Mass Media / Journalism'], 
    'Nursing (B.Sc Nursing / GNM)': ['Medical & Health Sciences'],
    'BBA (Business Administration)': ['Commerce & Management'],
    'BCA (Computer Applications)': ['Computer Applications & IT'],
    'MBBS / Medical Studies': ['Medical & Health Sciences'],
    'Pharmacy (B.Pharm / D.Pharm)': ['Medical & Health Sciences'],
    'Agriculture (B.Sc Agri)': ['Agriculture & Veterinary Sciences'],
    'Law (BA LLB / BBA LLB)': ['Law'],
    'Fashion Designing': ['Design, Architecture & Fine Arts'],
    'Hotel Management': ['Commerce & Management'],
    'Fine Arts (BFA)': ['Design, Architecture & Fine Arts'],
    'Mass Media / Journalism': ['Arts, Humanities & Social Sciences'],
    'Architecture (B.Arch)': ['Design, Architecture & Fine Arts'],
    'Event Management': ['Commerce & Management'],
    'Animation & Graphics': ['Design, Architecture & Fine Arts', 'Computer Applications & IT'],
    'Psychology': ['Arts, Humanities & Social Sciences', 'Science (Pure & Applied)', 'Medical & Health Sciences'],
    'Physiotherapy': ['Medical & Health Sciences'],

    // Postgraduate
    "Master's Degree (MA / MCom / MSc)": ['Science (Pure & Applied)', 'Commerce & Management', 'Arts, Humanities & Social Sciences', 'Education / Teaching / Training', 'Computer Applications & IT', 'Agriculture & Veterinary Sciences', 'Medical & Health Sciences', 'Design, Architecture & Fine Arts', 'Law'],
    'MCA (Computer Applications)': ['Computer Applications & IT'],
    'MBA (Business Administration)': ['Commerce & Management'],
    'M.Tech / ME': ['Engineering & Technology', 'Computer Applications & IT'],
    'Doctorate / PhD': ['Engineering & Technology', 'Medical & Health Sciences', 'Science (Pure & Applied)', 'Commerce & Management', 'Arts, Humanities & Social Sciences', 'Law', 'Agriculture & Veterinary Sciences', 'Design, Architecture & Fine Arts', 'Computer Applications & IT', 'Education / Teaching / Training'],
    'Postgraduate Diploma': ['Commerce & Management', 'Computer Applications & IT', 'Medical & Health Sciences', 'Education / Teaching / Training', 'Design, Architecture & Fine Arts', 'Law', 'Science (Pure & Applied)', 'Arts, Humanities & Social Sciences'],
    'Certificate Program': ['Computer Applications & IT', 'Commerce & Management', 'Design, Architecture & Fine Arts', 'Education / Teaching / Training', 'Medical & Health Sciences'],
    'Professional Course (CA / CS / CMA)': ['Commerce & Management', 'Law'],
};

const EducationEntryForm: React.FC<{
    entry: EducationEntry;
    onEducationChange: (id: string, e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
    onRemoveEducation: (id: string) => void;
    yearOptions: { value: string; label: string }[];
    educationFields: any[];
}> = ({ entry, onEducationChange, onRemoveEducation, yearOptions, educationFields }) => {
    
    const majorFieldOptions = useMemo(() => {
        let options = educationFields;
        // Filter options based on the selected level
        if (entry.level && levelToFieldMapping[entry.level]) {
            const allowedFields = levelToFieldMapping[entry.level];
            options = educationFields.filter(f => allowedFields.includes(f.name));
        }
        return options.map(field => ({ value: field.name, label: field.name }));
    }, [entry.level, educationFields]);
    
    const specializationOptions = useMemo(() => {
        const selectedField = educationFields.find(f => f.name === entry.field);
        return selectedField ? selectedField.subDepartments.map((s: string) => ({ value: s, label: s })) : [];
    }, [entry.field, educationFields]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        onEducationChange(entry.id, e);
    };

    return (
        <div className="space-y-4 p-4 border border-slate-200 dark:border-slate-700 rounded-lg relative">
            <button type="button" onClick={() => onRemoveEducation(entry.id)} className="absolute top-2 right-2 p-1 text-slate-400 hover:text-red-500">
                <TrashIcon className="w-5 h-5" />
            </button>

            <SelectField label="Level of Education" name="level" value={entry.level} onChange={handleChange} options={educationLevelOptions} />
            <SelectField label="Major Field" name="field" value={entry.field} onChange={handleChange} options={majorFieldOptions} disabled={!entry.level} />
            <SelectField label="Specialization / Sub-department" name="specialization" value={entry.specialization} onChange={handleChange} options={specializationOptions} disabled={!entry.field} />
            <InputField label="Institution / University Name" name="institution" value={entry.institution} onChange={handleChange} placeholder="e.g., University of Technology" />
            <InputField label="CGPA / Percentage" name="grade" value={entry.grade} onChange={handleChange} placeholder="e.g., 8.5/10.0" />
            <div className="grid grid-cols-2 gap-4">
                <SelectField label="Start Year" name="startYear" value={entry.startYear} onChange={handleChange} options={yearOptions} />
                <SelectField label="End Year" name="endYear" value={entry.endYear} onChange={handleChange} options={yearOptions} />
            </div>
        </div>
    );
};

const streamOptions = [
    { value: 'Science (PCM) – Physics, Chemistry, Mathematics', label: 'Science (PCM) – Physics, Chemistry, Mathematics' },
    { value: 'Science (PCB) – Physics, Chemistry, Biology', label: 'Science (PCB) – Physics, Chemistry, Biology' },
    { value: 'Commerce with Math', label: 'Commerce with Math' },
    { value: 'Commerce without Math', label: 'Commerce without Math' },
    { value: 'Arts / Humanities', label: 'Arts / Humanities' },
    { value: 'Vocational Studies', label: 'Vocational Studies' },
    { value: 'Information Technology', label: 'Information Technology' },
    { value: 'Computer Science', label: 'Computer Science' },
    { value: 'Agriculture', label: 'Agriculture' },
    { value: 'Home Science', label: 'Home Science' },
    { value: 'Fine Arts', label: 'Fine Arts' },
    { value: 'Diploma (Polytechnic)', label: 'Diploma (Polytechnic)' },
    { value: 'Hotel Management', label: 'Hotel Management' },
    { value: 'Fashion Designing', label: 'Fashion Designing' },
    { value: 'Travel & Tourism', label: 'Travel & Tourism' },
    { value: 'Mass Media', label: 'Mass Media' },
    { value: 'Other', label: 'Other' }
];

const ProfileForm: React.FC<ProfileFormProps> = ({ userType, profile, setProfile, onComplete, error, appData }) => {
  const { quizQuestions, educationFields, formStructureByField } = appData;
  const [currentStep, setCurrentStep] = useState(0);
  const [quizSubStep, setQuizSubStep] = useState<'start' | 'questions'>('start');
  const [fileError, setFileError] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [isUploading, setIsUploading] = useState<boolean>(false);

  const isStudent = userType === UserType.IN_EDUCATION;
  const formSteps = ["Personal Info", "Education", "Skills & Knowledge", "Career Quiz", "Interests & Aspirations"];

  const yearOptions = useMemo(() => {
    const endYear = 2040;
    const startYear = 1970;
    return Array.from({ length: endYear - startYear + 1 }, (_, i) => {
      const year = endYear - i;
      return { value: year.toString(), label: year.toString() };
    });
  }, []);

  const currentFormStructure = useMemo(() => {
    if (profile.educationHistory.length > 0) {
        const latestField = profile.educationHistory[profile.educationHistory.length - 1]?.field;
        if (latestField && formStructureByField[latestField]) {
            return formStructureByField[latestField];
        }
    }
    return formStructureByField.default;
  }, [profile.educationHistory, formStructureByField]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setProfile(prev => ({ ...prev, [name]: value }));
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files && e.target.files[0];
    setFileError(null);
    setUploadProgress(0);
    setProfile(prev => ({ ...prev, resume: null })); // Clear previous file

    if (!file) {
        e.target.value = '';
        return;
    }

    const acceptedMimeTypes = [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'text/plain',
        'image/jpeg',
        'image/png'
    ];
    if (!acceptedMimeTypes.includes(file.type)) {
        setFileError("Invalid file type. Please upload a PDF, DOC, DOCX, TXT, or image file.");
        e.target.value = '';
        return;
    }

    const MAX_FILE_SIZE_MB = 10;
    const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024;
    if (file.size > MAX_FILE_SIZE_BYTES) {
        setFileError(`File is too large. Maximum size is ${MAX_FILE_SIZE_MB}MB.`);
        e.target.value = '';
        return;
    }
    
    setIsUploading(true);
    let progress = 0;
    const interval = setInterval(() => {
        progress += 20;
        setUploadProgress(progress);
        if (progress >= 100) {
            clearInterval(interval);
            setProfile(prev => ({ ...prev, resume: file }));
            setIsUploading(false);
        }
    }, 150);
  };

  const nextStep = () => setCurrentStep(prev => Math.min(prev + 1, formSteps.length - 1));
  const prevStep = () => setCurrentStep(prev => Math.max(prev - 1, 0));
  
  const handleAddEducation = () => {
    setProfile(prev => ({
        ...prev,
        educationHistory: [
            ...prev.educationHistory,
            {
                id: Date.now().toString(),
                level: '', field: '', specialization: '',
                institution: '', grade: '', startYear: '', endYear: ''
            }
        ]
    }));
  };

  const handleRemoveEducation = (id: string) => {
    setProfile(prev => ({
        ...prev,
        educationHistory: prev.educationHistory.filter(entry => entry.id !== id)
    }));
  };

  const handleEducationChange = (id: string, e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setProfile(prev => ({
        ...prev,
        educationHistory: prev.educationHistory.map(entry => {
            if (entry.id === id) {
                if (name === 'field') {
                    return { ...entry, [name]: value, specialization: '' };
                }
                if (name === 'level') {
                    // Check if the current field is still valid for the new level
                    const allowedFields = levelToFieldMapping[value];
                    let newField = entry.field;
                    let newSpecialization = entry.specialization;
                    
                    if (allowedFields && !allowedFields.includes(entry.field)) {
                        newField = '';
                        newSpecialization = '';
                    }
                    return { ...entry, [name]: value, field: newField, specialization: newSpecialization };
                }
                return { ...entry, [name]: value };
            }
            return entry;
        })
    }));
  };

  const handleAnswerChange = (questionId: string, answer: string) => {
    setProfile(prev => ({
      ...prev,
      quizAnswers: {
        ...prev.quizAnswers,
        [questionId]: answer,
      }
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onComplete(profile);
  };
  
  const isQuizStep = formSteps[currentStep] === 'Career Quiz';

  const renderStep = () => {
    const currentStepName = formSteps[currentStep];
    switch (currentStepName) {
      case "Personal Info":
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-slate-800 dark:text-slate-100">Let's start with the basics</h3>
            <InputField label="Full Name" name="name" value={profile.name} onChange={handleChange} placeholder="e.g., Jane Doe" />
            <InputField label="Email Address" name="email" value={profile.email} onChange={handleChange} placeholder="e.g., jane.doe@example.com" type="email" />
            <InputField label="Phone Number (Optional)" name="phone" value={profile.phone} onChange={handleChange} placeholder="e.g., (123) 456-7890" type="tel" />
            <InputField label="Age" name="age" value={profile.age} onChange={handleChange} placeholder="e.g., 21" />
            <InputField label="Location (City, Country)" name="location" value={profile.location} onChange={handleChange} placeholder="e.g., San Francisco, USA" />
          </div>
        );
      case "Education":
        return (
          <div>
            <h3 className="text-xl font-semibold text-slate-800 dark:text-slate-100 mb-4">Tell us about your education</h3>
            <div className="max-h-[55vh] overflow-y-auto space-y-6 pr-4">
                <div className="space-y-4 p-4 border border-slate-200 dark:border-slate-700 rounded-lg">
                    <h4 className="font-semibold text-slate-600 dark:text-slate-300">High School</h4>
                    <InputField label="10th Grade School Name" name="education10thSchool" value={profile.education10thSchool} onChange={handleChange} placeholder="e.g., Bharati High School" />
                    <InputField label="10th Grade Percentage / CGPA" name="education10th" value={profile.education10th} onChange={handleChange} placeholder="e.g., 95% or 10.0" />
                    <InputField label="12th Grade School / College Name" name="education12thSchool" value={profile.education12thSchool} onChange={handleChange} placeholder="e.g., Vivekananda Junior College" />
                    <InputField label="12th Grade Percentage / CGPA" name="education12th" value={profile.education12th} onChange={handleChange} placeholder="e.g., 92% or 9.5" />
                    <SelectField label="12th Grade Stream" name="education12thStream" value={profile.education12thStream} onChange={handleChange} options={streamOptions} />
                </div>
                
                <div className="space-y-4">
                    <h4 className="font-semibold text-slate-600 dark:text-slate-300">Higher Education</h4>
                    {profile.educationHistory.map((entry) => (
                        <EducationEntryForm
                            key={entry.id}
                            entry={entry}
                            onEducationChange={handleEducationChange}
                            onRemoveEducation={handleRemoveEducation}
                            yearOptions={yearOptions}
                            educationFields={educationFields}
                        />
                    ))}
                    <button type="button" onClick={handleAddEducation} className="w-full text-center py-2 px-4 border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-lg text-sm font-semibold text-blue-600 dark:text-blue-400 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">
                        + Add Qualification
                    </button>
                </div>
            </div>
          </div>
        );

      case "Skills & Knowledge":
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-slate-800 dark:text-slate-100">Skills & Knowledge</h3>
            {currentFormStructure.map((field: any) => (
                <InputField
                    key={field.name}
                    isTextArea={field.isTextArea}
                    label={field.label}
                    name={field.name}
                    value={(profile as any)[field.name] as string}
                    onChange={handleChange}
                    placeholder={field.placeholder}
                />
            ))}
          </div>
        );
      case "Career Quiz":
          const quizCategory = getQuizCategory();
          const questionsForStream = quizQuestions[quizCategory];
          const allQuestionsAnswered = questionsForStream.every((q: any) => profile.quizAnswers?.[q.id]);

          if (quizSubStep === 'start') {
              return (
                  <div className="space-y-6 py-10 text-center">
                       <div className="flex justify-center mb-4">
                           <div className="p-4 bg-blue-100 dark:bg-blue-900/50 rounded-full">
                               <CompassIcon className="w-12 h-12 text-blue-600 dark:text-blue-400" />
                           </div>
                       </div>
                      <h3 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Knowledge Check (Optional)</h3>
                      <p className="text-slate-600 dark:text-slate-300 max-w-md mx-auto">
                          Take a short 10-question quiz based on your background to help us gauge your domain knowledge. You can skip this if you prefer.
                      </p>
                      
                      <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-8">
                          <button 
                            type="button" 
                            onClick={() => setQuizSubStep('questions')}
                            className="w-full sm:w-auto px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-semibold shadow-lg"
                          >
                              Start Quiz
                          </button>
                          <button 
                            type="button" 
                            onClick={nextStep}
                            className="w-full sm:w-auto px-8 py-3 bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-lg hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors font-medium"
                          >
                              Skip for Now
                          </button>
                      </div>
                  </div>
              );
          }

          if (quizSubStep === 'questions') {
            return (
                <div className="space-y-4">
                    <h3 className="text-xl font-semibold text-slate-800 dark:text-slate-100">Career Knowledge Quiz</h3>
                    <p className="text-sm text-slate-500 dark:text-slate-400">
                        Answer these 10 questions to help us get a better sense of your knowledge.
                    </p>
                    <div className="max-h-[350px] overflow-y-auto space-y-4 pr-2">
                        {questionsForStream.map((q: any, index: number) => (
                            <div key={q.id} className="p-3 bg-slate-50 dark:bg-slate-700/50 rounded-lg">
                                <p className="font-semibold text-sm text-slate-800 dark:text-slate-200">{index + 1}. {q.question}</p>
                                <fieldset className="mt-2 space-y-2">
                                    {q.options.map((option: string) => (
                                        <div key={option} className="flex items-center">
                                            <input
                                                id={`${q.id}-${option}`}
                                                name={`answer-${q.id}`}
                                                type="radio"
                                                checked={profile.quizAnswers?.[q.id] === option}
                                                onChange={() => handleAnswerChange(q.id, option)}
                                                className="h-4 w-4 border-slate-300 text-blue-600 focus:ring-blue-500"
                                            />
                                            <label htmlFor={`${q.id}-${option}`} className="ml-2 block text-sm text-slate-700 dark:text-slate-300">{option}</label>
                                        </div>
                                    ))}
                                </fieldset>
                            </div>
                        ))}
                    </div>
                     { !allQuestionsAnswered && <p className="text-xs text-center text-slate-500 dark:text-slate-400">Please answer all questions before proceeding.</p> }
                </div>
            );
          }

          return null; // Fallback
          
       case "Interests & Aspirations":
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-slate-800 dark:text-slate-100">What are your goals?</h3>
             <InputField isTextArea label="Favorite Subjects" name="favoriteSubjects" value={profile.favoriteSubjects} onChange={handleChange} placeholder="e.g., Artificial Intelligence, History, Graphic Design" />
            <InputField isTextArea label="Preferred Industries / Domains" name="preferredIndustries" value={profile.preferredIndustries} onChange={handleChange} placeholder="e.g., IT, Healthcare, Finance, Creative Arts" />
            <InputField label="Work Preferences" name="workPreferences" value={profile.workPreferences} onChange={handleChange} placeholder="e.g., Remote, On-site, Hybrid" />
            <InputField label="Interest in Higher Studies vs. Job" name="higherStudies" value={profile.higherStudies} onChange={handleChange} placeholder="e.g., Plan to pursue a Master's, Eager to find a job" />
            <InputField isTextArea label="Dream Job Role(s)" name="dreamJobRoles" value={profile.dreamJobRoles} onChange={handleChange} placeholder="e.g., Software Engineer at Google, Freelance Designer" />
            
            {!isStudent && (
              <div className="space-y-4 pt-4 mt-4 border-t border-slate-200 dark:border-slate-700">
                <h3 className="text-xl font-semibold text-slate-800 dark:text-slate-100">Upload Your Resume</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400">
                    For the best analysis, please upload your resume. We accept PDF, DOC, DOCX, TXT, and image formats (max 10MB).
                </p>
                <div>
                    <div className={`mt-1 flex justify-center px-6 pt-5 pb-6 border-2 ${fileError ? 'border-red-400 dark:border-red-500' : 'border-slate-300 dark:border-slate-600'} border-dashed rounded-md transition-colors`}>
                        <div className="space-y-2 text-center w-full">
                            
                            { !isUploading && !profile.resume && <UploadIcon /> }

                            <div className="flex text-sm text-slate-600 dark:text-slate-400 justify-center">
                                <label htmlFor="resume-upload" className={`relative cursor-pointer bg-white dark:bg-slate-700 rounded-md font-medium text-blue-600 dark:text-blue-400 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500 ${isUploading ? 'opacity-50 cursor-not-allowed' : ''}`}>
                                    <span>{profile.resume ? 'Change file' : 'Upload a file'}</span>
                                    <input id="resume-upload" name="resume" type="file" className="sr-only" onChange={handleFileChange} accept=".pdf,.doc,.docx,.txt,image/*" disabled={isUploading} />
                                </label>
                                { !profile.resume && !isUploading && <p className="pl-1">or drag and drop</p> }
                            </div>
                            <p className="text-xs text-slate-500 dark:text-slate-500">PDF, DOC, DOCX, TXT, JPG, PNG up to 10MB</p>

                            {isUploading && (
                                <div className="pt-2">
                                    <div className="w-full bg-slate-200 rounded-full h-2.5 dark:bg-slate-700">
                                        <div className="bg-blue-600 h-2.5 rounded-full transition-all duration-150" style={{ width: `${uploadProgress}%` }}></div>
                                    </div>
                                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Processing...</p>
                                </div>
                            )}
                            
                            {fileError && <p className="text-sm text-red-500 mt-2">{fileError}</p>}
                            
                            {profile.resume && !isUploading && (
                                <div className="flex items-center justify-center gap-2 text-sm text-green-600 dark:text-green-400 mt-2">
                                    <CheckCircleIcon className="w-5 h-5"/>
                                    <span>{profile.resume.name} selected</span>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
              </div>
            )}
          </div>
        );
      default:
        return null;
    }
  };

  const progress = ((currentStep + 1) / formSteps.length) * 100;
  
  const getQuizCategory = () => {
      const latestField = profile.educationHistory.length > 0 ? profile.educationHistory[profile.educationHistory.length - 1]?.field : '';

      if (latestField) {
          const fieldMapping: { [key: string]: 'science' | 'commerce' | 'arts' } = {
              "Engineering & Technology": 'science',
              "Medical & Health Sciences": 'science',
              "Science (Pure & Applied)": 'science',
              "Computer Applications & IT": 'science',
              "Agriculture & Veterinary Sciences": 'science',
              "Commerce & Management": 'commerce',
              "Arts, Humanities & Social Sciences": 'arts',
              "Law": 'arts',
              "Design, Architecture & Fine Arts": 'arts',
              "Education / Teaching / Training": 'arts'
          };
          return fieldMapping[latestField] || 'default';
      }

      const stream = (profile.education12thStream || '').toLowerCase();
      if (stream.includes('science')) return 'science';
      if (stream.includes('commerce')) return 'commerce';
      if (stream.includes('arts')) return 'arts';

      return 'default';
  };

  const quizCategory = getQuizCategory();
  const questionsForStream = quizQuestions[quizCategory] || quizQuestions.default;
  const isQuizComplete = questionsForStream.every((q: any) => profile.quizAnswers?.[q.id]);
  const isNextButtonDisabled = isQuizStep && quizSubStep === 'questions' && !isQuizComplete;

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-xl p-8">
          <h2 className="text-2xl font-bold text-center text-slate-800 dark:text-white mb-2">Create Your Career Profile</h2>
          <p className="text-center text-slate-500 dark:text-slate-400 mb-6">Complete these steps to unlock your personalized recommendations.</p>
          
          <div>
            <div className="flex justify-between mb-1">
              <span className="text-base font-medium text-blue-700 dark:text-white">{formSteps[currentStep]}</span>
              <span className="text-sm font-medium text-blue-700 dark:text-white">{currentStep + 1} / {formSteps.length}</span>
            </div>
            <div className="w-full bg-slate-200 rounded-full h-2.5 dark:bg-slate-700">
              <div className="bg-blue-600 h-2.5 rounded-full transition-all duration-500" style={{ width: `${progress}%` }}></div>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="mt-8">
            <div className="min-h-[400px]">
              {renderStep()}
            </div>
            
            {error && <p className="text-red-500 text-xs mt-4 text-center">{error}</p>}
            
            <div className="mt-8 flex justify-between items-center">
              <button 
                type="button" 
                onClick={
                    isQuizStep && quizSubStep === 'questions' ? () => setQuizSubStep('start') : 
                    prevStep
                } 
                disabled={currentStep === 0} 
                className="flex items-center gap-2 px-4 py-2 bg-slate-200 dark:bg-slate-600 text-slate-800 dark:text-slate-100 rounded-md disabled:opacity-50 hover:bg-slate-300 dark:hover:bg-slate-500 transition-colors"
                >
                <ArrowLeftIcon />
                Back
              </button>
              
              {currentStep < formSteps.length - 1 ? (
                <button 
                    type="button" 
                    onClick={nextStep} 
                    disabled={isNextButtonDisabled}
                    className="flex items-center gap-2 px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    style={{ display: isQuizStep && quizSubStep === 'start' ? 'none' : 'flex' }}
                    >
                    Next
                    <ArrowRightIcon />
                  </button>
              ) : (
                <button type="submit" className={`flex items-center gap-2 px-6 py-2 text-white rounded-md transition-colors font-semibold ${isStudent ? 'bg-blue-600 hover:bg-blue-700' : 'bg-green-600 hover:bg-green-700'}`}>
                  {isStudent ? 'Build My Resume' : 'Get Recommendations'}
                  {isStudent ? <BriefcaseIcon/> : <SparklesIcon />}
                </button>
              )}
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ProfileForm;
