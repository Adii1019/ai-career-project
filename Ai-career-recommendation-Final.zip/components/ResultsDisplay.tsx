
import React, { useState } from 'react';
import { CareerRecommendation, Resource } from '../types';
import { ChevronDownIcon, LightbulbIcon, TargetIcon, BookOpenIcon, CheckCircleIcon, SparklesIcon, HomeIcon, YoutubeIcon, CourseIcon, ExternalLinkIcon, AlertTriangleIcon } from './icons';

interface ResultsDisplayProps {
  recommendations: CareerRecommendation[];
  onReset: () => void;
}

const ResourceLink: React.FC<{ resource: Resource }> = ({ resource }) => (
    <a href={resource.url} target="_blank" rel="noopener noreferrer" className="group flex items-center justify-between p-2 text-sm text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-700/50 rounded-md hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors">
        <span className="truncate pr-2">{resource.title}</span>
        <ExternalLinkIcon className="w-4 h-4 text-slate-400 dark:text-slate-500 group-hover:text-blue-500 transition-colors shrink-0" />
    </a>
);

const ResourceSection: React.FC<{ title: string; icon: React.ReactNode; resources: Resource[] }> = ({ title, icon, resources }) => (
    <div className="space-y-2">
        <h4 className="font-semibold text-slate-600 dark:text-slate-200 flex items-center gap-2 text-sm">
            {icon} {title}
        </h4>
        {resources && resources.length > 0 ? (
            <div className="space-y-2">
                {resources.map((resource, index) => <ResourceLink key={index} resource={resource} />)}
            </div>
        ) : (
            <p className="text-xs text-slate-400 dark:text-slate-500 italic">No resources found.</p>
        )}
    </div>
);

const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ recommendations, onReset }) => {
  const [openAccordion, setOpenAccordion] = useState<string | null>(recommendations[0]?.careerTitle || null);
  
  const handleAccordionClick = (careerTitle: string) => {
    setOpenAccordion(openAccordion === careerTitle ? null : careerTitle);
  };
    
  return (
    <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center">
            <div className="flex justify-center items-center gap-3 text-3xl font-extrabold text-slate-900 dark:text-white sm:text-4xl">
                <SparklesIcon />
                <h1>Your Personalized Career Path</h1>
            </div>
          <p className="mt-4 text-lg text-slate-600 dark:text-slate-400">
            Based on your profile, here are the top career recommendations from our AI.
          </p>
        </div>
        
        <div className="mt-12 bg-white dark:bg-slate-800 rounded-2xl shadow-xl overflow-hidden">
          {recommendations.map((rec, index) => (
            <div key={index} className="border-b-4 border-slate-100 dark:border-slate-900 last:border-b-0">
                <button
                    onClick={() => handleAccordionClick(rec.careerTitle)}
                    className="w-full text-left p-6 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors"
                >
                    <div className="flex justify-between items-center">
                        <div>
                            <p className="text-sm font-semibold text-blue-600 dark:text-blue-400">RECOMMENDATION #{index + 1}</p>
                            <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100 mt-1">{rec.careerTitle}</h2>
                        </div>
                        <ChevronDownIcon className={`w-8 h-8 text-slate-400 transition-transform ${openAccordion === rec.careerTitle ? 'rotate-180' : ''}`} />
                    </div>
                </button>
                <div className={`transition-all duration-500 ease-in-out overflow-hidden ${openAccordion === rec.careerTitle ? 'max-h-full' : 'max-h-0'}`}>
                    <div className="px-6 pb-6">
                        <p className="text-slate-600 dark:text-slate-300 mb-6">{rec.description}</p>
                        
                        <div className="space-y-4">
                            <div>
                                <h3 className="font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-2 mb-2"><LightbulbIcon /> Why it's a good fit:</h3>
                                <p className="text-sm text-slate-600 dark:text-slate-400">{rec.relevanceJustification}</p>
                            </div>
                             <div>
                                <h3 className="font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-2 mb-2"><TargetIcon /> Your Skill Gaps:</h3>
                                <ul className="list-disc list-inside space-y-1">
                                    {rec.skillGaps.map((gap, i) => (
                                        <li key={i} className="text-sm text-slate-600 dark:text-slate-400">{gap}</li>
                                    ))}
                                </ul>
                            </div>
                            <div>
                                <h3 className="font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-2 mb-2"><BookOpenIcon /> Recommended Learning Path:</h3>
                                <div className="space-y-3">
                                {rec.learningPath.map((path, i) => (
                                    <div key={i} className="p-3 bg-slate-100 dark:bg-slate-700/50 rounded-lg">
                                        <p className="font-semibold text-sm text-slate-800 dark:text-slate-200 flex items-center gap-2">
                                            <CheckCircleIcon className="text-green-500 shrink-0" />
                                            {path.step}: <span className="font-normal">{path.recommendation}</span>
                                        </p>
                                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 pl-6">{path.details}</p>
                                    </div>
                                ))}
                                </div>
                            </div>
                        </div>

                        {/* Curated Resources Section */}
                        <div className="mt-6 border-t border-slate-200 dark:border-slate-700 pt-4">
                            <h3 className="font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-2 mb-4 text-base">
                                <SparklesIcon /> Curated Resources to Get Started
                            </h3>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <ResourceSection title="Watch & Learn" icon={<YoutubeIcon className="text-red-500"/>} resources={rec.youtubeTutorials} />
                                <ResourceSection title="Free Courses" icon={<CourseIcon className="text-blue-500"/>} resources={rec.freeCourses} />
                                <ResourceSection title="Reading Material" icon={<BookOpenIcon className="text-yellow-500"/>} resources={rec.ebooksOrBlogs} />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          ))}
        </div>
        
        <div className="mt-12 text-center">
            <button
            onClick={onReset}
            className="inline-flex items-center gap-2 px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
                <HomeIcon/>
                Start Over
            </button>
        </div>
      </div>
    </div>
  );
};

export default ResultsDisplay;
