import React from 'react';
import { UserType } from '../types';
import { SchoolIcon, BriefcaseIcon, SparklesIcon } from './icons';

interface UserTypeSelectorProps {
  onSelect: (userType: UserType) => void;
}

const UserTypeSelector: React.FC<UserTypeSelectorProps> = ({ onSelect }) => {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4">
      <div className="text-center mb-12">
        <div className="flex justify-center items-center gap-3 text-4xl font-bold text-slate-800 dark:text-white">
          <SparklesIcon/>
          <h1>AI Career Recommendation</h1>
        </div>
        <p className="mt-4 text-lg text-slate-600 dark:text-slate-300">
          Navigate your future. Let's find the perfect career path for you.
        </p>
      </div>

      <div className="w-full max-w-4xl mx-auto">
        <h2 className="text-2xl font-semibold text-center text-slate-700 dark:text-slate-200 mb-8">First, tell us about your current status:</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <button
            onClick={() => onSelect(UserType.IN_EDUCATION)}
            className="group p-8 bg-white dark:bg-slate-800 rounded-2xl shadow-lg hover:shadow-2xl border border-transparent hover:border-blue-500 transition-all duration-300 ease-in-out transform hover:-translate-y-2"
          >
            <div className="flex flex-col items-center text-center">
              <div className="p-5 bg-blue-100 dark:bg-blue-900/50 rounded-full mb-6">
                <SchoolIcon className="w-12 h-12 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="text-2xl font-bold text-slate-800 dark:text-white mb-2">I'm a Student</h3>
              <p className="text-slate-500 dark:text-slate-400">
                Currently in high school, college, or university, exploring future career options.
              </p>
            </div>
          </button>
          
          <button
            onClick={() => onSelect(UserType.COMPLETED_EDUCATION)}
            className="group p-8 bg-white dark:bg-slate-800 rounded-2xl shadow-lg hover:shadow-2xl border border-transparent hover:border-green-500 transition-all duration-300 ease-in-out transform hover:-translate-y-2"
          >
            <div className="flex flex-col items-center text-center">
              <div className="p-5 bg-green-100 dark:bg-green-900/50 rounded-full mb-6">
                 <BriefcaseIcon className="w-12 h-12 text-green-600 dark:text-green-400" />
              </div>
              <h3 className="text-2xl font-bold text-slate-800 dark:text-white mb-2">I'm a Graduate</h3>
              <p className="text-slate-500 dark:text-slate-400">
                Have completed my education and possess a resume. Ready for the job market or a career change.
              </p>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};

export default UserTypeSelector;