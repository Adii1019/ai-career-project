
import React, { useState } from 'react';
import { MailIcon } from './icons';

interface VerificationPendingProps {
  email: string;
  onVerify: () => Promise<void>;
  onBackToSignIn: () => void;
}

const VerificationPending: React.FC<VerificationPendingProps> = ({ email, onVerify, onBackToSignIn }) => {
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleVerifyClick = async () => {
        setError(null);
        setIsLoading(true);
        try {
            await onVerify();
        } catch (err: any) {
            setError(err.message);
        } finally {
            setIsLoading(false);
        }
    }

  return (
    <div className="min-h-screen flex flex-col justify-center items-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-xl p-8 text-center">
          <div className="flex justify-center mb-6">
            <div className="p-4 bg-blue-100 dark:bg-blue-900/50 rounded-full">
              <MailIcon className="w-10 h-10 text-blue-600 dark:text-blue-400" />
            </div>
          </div>
          <h2 className="text-2xl font-bold text-slate-800 dark:text-white">Verify Your Email</h2>
          <p className="text-slate-500 dark:text-slate-400 mt-2">
            We've sent a verification link to <strong className="text-slate-700 dark:text-slate-200">{email}</strong>. Please check your inbox to continue.
          </p>
          
          <div className="mt-8">
            <button
              onClick={handleVerifyClick}
              disabled={isLoading}
              className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors disabled:opacity-50"
            >
              {isLoading ? 'Verifying...' : 'Simulate Email Verification'}
            </button>
          </div>
          
          {error && <p className="text-red-500 text-xs text-center mt-4">{error}</p>}

          <p className="mt-6 text-center text-sm text-slate-500 dark:text-slate-400">
            Wrong email? Or want to sign in?{' '}
            <button onClick={onBackToSignIn} className="font-medium text-blue-600 hover:text-blue-500 dark:text-blue-400 dark:hover:text-blue-300">
              Go to Sign In
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default VerificationPending;